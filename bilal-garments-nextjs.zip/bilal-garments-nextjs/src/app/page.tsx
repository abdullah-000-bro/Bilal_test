import type { Metadata } from "next";
import { LuxuryHeader } from "@/components/layout/LuxuryHeader";
import { LuxuryFooter } from "@/components/layout/LuxuryFooter";
import { CinematicHero } from "@/components/home/CinematicHero";
import { FeaturedCategories } from "@/components/home/FeaturedCategories";
import { TrendingCollection } from "@/components/home/TrendingCollection";
import { AboutBrand } from "@/components/home/AboutBrand";
import { WhyChooseUs } from "@/components/home/WhyChooseUs";
import { FashionGallery } from "@/components/home/FashionGallery";
import { LocationSection } from "@/components/home/LocationSection";
import { Reviews } from "@/components/home/Reviews";
import { BrandsMarquee } from "@/components/home/BrandsMarquee";
import { HomeClient } from "@/components/home/HomeClient";

export const metadata: Metadata = {
  title: "BILAL GARMENTS — Cinematic Luxury Fashion from Lahore",
  description:
    "Hand-tailored Pakistani luxury, engineered for the bold. Limited drops, nationwide delivery, cinematic craftsmanship.",
  openGraph: {
    title: "BILAL GARMENTS — Cinematic Luxury Fashion",
    description: "Hand-tailored Pakistani luxury for the bold. Limited drops only.",
  },
};

export default function HomePage() {
  return (
    <HomeClient>
      <LuxuryHeader />
      <main>
        <CinematicHero />
        <FeaturedCategories />
        <TrendingCollection />
        <AboutBrand />
        <WhyChooseUs />
        <FashionGallery />
        <Reviews />
        <LocationSection />
      </main>
      <BrandsMarquee />
      <LuxuryFooter />
    </HomeClient>
  );
}
