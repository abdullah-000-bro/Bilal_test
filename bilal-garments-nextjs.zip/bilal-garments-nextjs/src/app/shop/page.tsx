import type { Metadata } from "next";
import { ShopClient } from "./ShopClient";

export const metadata: Metadata = {
  title: "Shop — BILAL GARMENTS",
  description:
    "Browse the full BILAL GARMENTS collection — kurtas, sherwanis, jackets, and more, hand-tailored in Pakistan.",
  openGraph: {
    title: "Shop the Collection — BILAL GARMENTS",
    description: "Limited drops, cinematic craftsmanship. Shop the latest.",
  },
};

export default function ShopPage() {
  return <ShopClient />;
}
