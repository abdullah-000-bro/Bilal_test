"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { Heart, SlidersHorizontal, X, Search, Check, Loader2 } from "lucide-react";
import { useLenis } from "@/hooks/useLenis";
import { useGsapReveal } from "@/hooks/useGsapReveal";
import { LuxuryHeader } from "@/components/layout/LuxuryHeader";
import { LuxuryFooter } from "@/components/layout/LuxuryFooter";
import { fmtPKR } from "@/lib/products";
import { useStore } from "@/lib/store";

const CATEGORIES = ["All", "Men", "Boys", "Kids"] as const;
const TAGS = ["New", "Trending", "Limited"] as const;
type Sort = "featured" | "price_asc" | "price_desc" | "name";

export function ShopClient() {
  useLenis();
  const ref = useGsapReveal<HTMLDivElement>();
  const { addToCart, toggleWishlist, isWished, fetchProducts, products, loadingProducts } = useStore();

  const [category, setCategory] = useState<string>("All");
  const [sort, setSort]         = useState<Sort>("featured");
  const [query, setQuery]       = useState("");
  const [activeTags, setActiveTags] = useState<string[]>([]);
  const [drawerOpen, setDrawerOpen] = useState(false);

  // Fetch from PHP API
  useEffect(() => {
    const params: Record<string, string | number> = { per_page: 50, sort };
    if (category !== "All") params.category = category.toLowerCase();
    if (query) params.search = query;
    if (activeTags.length === 1) params.tag = activeTags[0];
    fetchProducts(params);
  }, [category, sort, activeTags, fetchProducts]);

  // Debounce search
  useEffect(() => {
    if (!query) return;
    const t = setTimeout(() => {
      const params: Record<string, string | number> = { per_page: 50, sort, search: query };
      if (category !== "All") params.category = category.toLowerCase();
      fetchProducts(params);
    }, 400);
    return () => clearTimeout(t);
  }, [query]);

  const items = useMemo(() => {
    let list = [...products];
    if (activeTags.length > 1) list = list.filter((p) => p.tag && activeTags.includes(p.tag));
    return list;
  }, [products, activeTags]);

  const toggleTag = (t: string) =>
    setActiveTags((prev) => prev.includes(t) ? prev.filter((x) => x !== t) : [...prev, t]);

  const resetAll = () => {
    setCategory("All"); setSort("featured");
    setQuery(""); setActiveTags([]);
  };

  const activeCount =
    (category !== "All" ? 1 : 0) + (query ? 1 : 0) + activeTags.length;

  useEffect(() => {
    document.body.style.overflow = drawerOpen ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [drawerOpen]);

  return (
    <div ref={ref} className="relative z-10 text-foreground min-h-screen">
      <LuxuryHeader />
      <main className="pt-28 sm:pt-36">
        {/* Hero */}
        <section className="px-4 sm:px-8">
          <div className="mx-auto max-w-7xl">
            <div className="text-[10px] sm:text-xs tracking-[0.3em] uppercase text-primary mb-3" data-reveal>
              · The Collection
            </div>
            <h1 className="font-display text-4xl sm:text-7xl lg:text-8xl leading-[0.95] mb-4 sm:mb-6" data-reveal>
              Shop the Edit.
            </h1>
            <p className="max-w-xl text-foreground/70 text-sm sm:text-lg" data-reveal>
              Limited drops. Hand-tailored in Lahore. Engineered for the bold.
            </p>
          </div>
        </section>

        {/* Sticky toolbar */}
        <section className="px-3 sm:px-8 mt-8 sm:mt-14 sticky top-16 sm:top-24 z-30">
          <div className="mx-auto max-w-7xl glass rounded-2xl sm:rounded-full shadow-luxury p-2 sm:p-3">
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-2 flex-1 px-3 py-2 rounded-xl sm:rounded-full bg-glass min-w-0">
                <Search className="size-4 text-foreground/60 shrink-0" />
                <input
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Search the edit…"
                  className="flex-1 min-w-0 bg-transparent text-sm outline-none placeholder:text-foreground/40"
                />
                {query && (
                  <button onClick={() => setQuery("")} className="p-1 rounded-full hover:bg-glass">
                    <X className="size-3.5" />
                  </button>
                )}
              </div>

              <select
                value={sort}
                onChange={(e) => setSort(e.target.value as Sort)}
                className="hidden md:block bg-glass rounded-full text-sm text-foreground/80 focus:outline-none cursor-pointer px-4 py-2"
              >
                <option value="featured" className="bg-background">Featured</option>
                <option value="name" className="bg-background">Name A → Z</option>
                <option value="price_asc" className="bg-background">Price: Low → High</option>
                <option value="price_desc" className="bg-background">Price: High → Low</option>
              </select>

              <button
                onClick={() => setDrawerOpen(true)}
                className="relative shrink-0 inline-flex items-center gap-2 px-3 sm:px-5 py-2 rounded-xl sm:rounded-full bg-foreground text-background text-sm font-medium hover:opacity-90"
              >
                <SlidersHorizontal className="size-4" />
                <span className="hidden sm:inline">Filters</span>
                {activeCount > 0 && (
                  <span className="size-5 grid place-items-center rounded-full bg-primary text-primary-foreground text-[10px] font-semibold">
                    {activeCount}
                  </span>
                )}
              </button>
            </div>

            <div className="flex items-center gap-1.5 mt-2 overflow-x-auto no-scrollbar px-1">
              {CATEGORIES.map((c) => (
                <button
                  key={c}
                  onClick={() => setCategory(c)}
                  className={`shrink-0 px-3.5 py-1.5 rounded-full text-xs sm:text-sm transition-all whitespace-nowrap ${
                    category === c ? "bg-foreground text-background" : "text-foreground/70 hover:text-foreground hover:bg-glass"
                  }`}
                >
                  {c}
                </button>
              ))}
              <span className="mx-1 h-4 w-px bg-border/60 shrink-0" />
              {TAGS.map((t) => {
                const on = activeTags.includes(t);
                return (
                  <button
                    key={t}
                    onClick={() => toggleTag(t)}
                    className={`shrink-0 px-3 py-1.5 rounded-full text-xs sm:text-sm transition-all whitespace-nowrap inline-flex items-center gap-1 ${
                      on ? "bg-primary text-primary-foreground" : "text-foreground/70 hover:text-foreground hover:bg-glass"
                    }`}
                  >
                    {on && <Check className="size-3" />}{t}
                  </button>
                );
              })}
            </div>
          </div>
        </section>

        {/* Grid */}
        <section className="px-3 sm:px-8 mt-6 sm:mt-10 pb-24">
          <div className="mx-auto max-w-7xl">
            <div className="flex items-center justify-between mb-4 sm:mb-6 px-1">
              <span className="text-[11px] sm:text-xs uppercase tracking-[0.2em] text-foreground/50 flex items-center gap-2">
                {loadingProducts ? (
                  <><Loader2 className="size-3 animate-spin" /> Loading…</>
                ) : `${items.length} piece${items.length !== 1 ? "s" : ""}`}
              </span>
              {activeCount > 0 && (
                <button onClick={resetAll} className="text-xs text-primary hover:underline">Clear all</button>
              )}
            </div>

            {loadingProducts ? (
              <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-6 lg:gap-8">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="rounded-3xl bg-white/5 animate-pulse aspect-[3/4]" />
                ))}
              </div>
            ) : items.length === 0 ? (
              <div className="text-center py-24 text-foreground/60">
                <p className="text-sm sm:text-base mb-4">Nothing matches your filters.</p>
                <button onClick={resetAll} className="px-5 py-2.5 rounded-full glass text-sm">
                  Reset filters
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-6 lg:gap-8">
                {items.map((p) => (
                  <article key={p.id} className="group relative">
                    <div className="relative aspect-[3/4] rounded-2xl sm:rounded-3xl overflow-hidden bg-card shadow-float">
                      <Link href={`/product/${p.id}`} aria-label={p.name} className="absolute inset-0 z-10">
                        <Image
                          src={p.img}
                          alt={p.name}
                          fill
                          loading="lazy"
                          className="object-cover transition-transform duration-[1200ms] ease-cinematic group-hover:scale-105"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-background/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700" />
                      </Link>
                      {p.tag && (
                        <span className="absolute top-2.5 left-2.5 sm:top-4 sm:left-4 z-20 px-2.5 py-1 rounded-full text-[9px] sm:text-[10px] tracking-[0.18em] uppercase glass">
                          <span className={p.tag === "New" || p.tag === "Limited" ? "text-primary" : ""}>{p.tag}</span>
                        </span>
                      )}
                      <button
                        aria-label={isWished(p.id) ? "Remove from wishlist" : "Add to wishlist"}
                        onClick={() => toggleWishlist(p.id, p.name)}
                        className="absolute top-2.5 right-2.5 sm:top-4 sm:right-4 z-20 size-8 sm:size-10 grid place-items-center rounded-full glass transition-all hover:scale-110"
                      >
                        <Heart className={`size-3.5 sm:size-4 transition-colors ${isWished(p.id) ? "fill-primary text-primary" : ""}`} />
                      </button>
                      <div className="absolute inset-x-2 bottom-2 sm:inset-x-3 sm:bottom-3 z-20 sm:translate-y-2 sm:opacity-0 sm:group-hover:translate-y-0 sm:group-hover:opacity-100 transition-all duration-500 ease-cinematic">
                        <button
                          onClick={() => addToCart({ id: p.id, name: p.name, price: p.price, img: p.img })}
                          className="w-full py-2.5 sm:py-3 rounded-full bg-foreground text-background text-[11px] sm:text-xs font-semibold tracking-wider uppercase hover:bg-primary hover:text-primary-foreground transition-colors"
                        >
                          Add to Bag
                        </button>
                      </div>
                    </div>
                    <div className="mt-3 sm:mt-4 flex items-start justify-between gap-2 px-1">
                      <div className="min-w-0">
                        <Link href={`/product/${p.id}`} className="text-xs sm:text-base font-medium leading-snug hover:text-primary transition-colors line-clamp-2">
                          {p.name}
                        </Link>
                        <p className="text-[10px] sm:text-xs text-foreground/50 mt-0.5 uppercase tracking-wider">
                          {p.category}
                        </p>
                      </div>
                      <div className="text-right shrink-0">
                        {p.sale_price ? (
                          <>
                            <p className="text-xs sm:text-sm text-primary">{fmtPKR(p.sale_price)}</p>
                            <p className="text-[10px] sm:text-xs text-foreground/40 line-through">{fmtPKR(p.price)}</p>
                          </>
                        ) : (
                          <span className="text-xs sm:text-base text-foreground/80">{fmtPKR(p.price)}</span>
                        )}
                      </div>
                    </div>
                  </article>
                ))}
              </div>
            )}
          </div>
        </section>
      </main>
      <LuxuryFooter />

      {/* Filter drawer */}
      <div
        className={`fixed inset-0 z-[65] transition-all duration-500 ease-cinematic ${
          drawerOpen ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
        }`}
      >
        <div className="absolute inset-0 bg-background/80 backdrop-blur-xl" onClick={() => setDrawerOpen(false)} />
        <div className={`absolute right-0 top-0 bottom-0 w-full sm:w-[420px] bg-background border-l border-border/40 flex flex-col transition-transform duration-500 ease-cinematic ${drawerOpen ? "translate-x-0" : "translate-x-full"}`}>
          <div className="flex items-center justify-between p-5 border-b border-border/40">
            <h3 className="font-display text-xl tracking-wide">Filters</h3>
            <button onClick={() => setDrawerOpen(false)} className="p-2 rounded-full hover:bg-glass">
              <X className="size-5" />
            </button>
          </div>
          <div className="flex-1 overflow-y-auto px-5 py-6 space-y-8">
            {/* Sort */}
            <div>
              <p className="text-xs uppercase tracking-[0.25em] text-foreground/50 mb-3">Sort by</p>
              <div className="grid grid-cols-2 gap-2">
                {([
                  ["featured",   "Featured"],
                  ["name",       "Name A→Z"],
                  ["price_asc",  "Price ↑"],
                  ["price_desc", "Price ↓"],
                ] as const).map(([val, label]) => (
                  <button
                    key={val}
                    onClick={() => setSort(val)}
                    className={`px-3 py-2.5 rounded-xl text-sm transition-all ${sort === val ? "bg-foreground text-background" : "bg-glass text-foreground/80 hover:text-foreground"}`}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </div>
            {/* Category */}
            <div>
              <p className="text-xs uppercase tracking-[0.25em] text-foreground/50 mb-3">Category</p>
              <div className="flex flex-wrap gap-2">
                {CATEGORIES.map((c) => (
                  <button
                    key={c}
                    onClick={() => setCategory(c)}
                    className={`px-4 py-2 rounded-full text-sm transition-all ${category === c ? "bg-foreground text-background" : "bg-glass text-foreground/80 hover:text-foreground"}`}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>
            {/* Tags */}
            <div>
              <p className="text-xs uppercase tracking-[0.25em] text-foreground/50 mb-3">Tags</p>
              <div className="flex flex-wrap gap-2">
                {TAGS.map((t) => {
                  const on = activeTags.includes(t);
                  return (
                    <button
                      key={t}
                      onClick={() => toggleTag(t)}
                      className={`px-4 py-2 rounded-full text-sm transition-all inline-flex items-center gap-1.5 ${on ? "bg-primary text-primary-foreground" : "bg-glass text-foreground/80 hover:text-foreground"}`}
                    >
                      {on && <Check className="size-3.5" />}{t}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
          <div className="p-5 border-t border-border/40 flex items-center gap-2">
            <button onClick={resetAll} className="flex-1 py-3 rounded-full glass text-sm hover:bg-glass">Reset</button>
            <button onClick={() => setDrawerOpen(false)} className="flex-[1.4] py-3 rounded-full bg-primary text-primary-foreground text-sm font-medium">
              Show {items.length} piece{items.length !== 1 ? "s" : ""}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
