import type { Metadata } from "next";
import { Toaster } from "sonner";
import "./globals.css";
import { StoreProvider } from "@/lib/store";
import { AdminProvider } from "@/lib/admin-store";
import { AmbientBackground } from "@/components/layout/AmbientBackground";

export const metadata: Metadata = {
  title: "BILAL GARMENTS — Cinematic Luxury Fashion",
  description:
    "Premium Pakistani fashion. Cinematic, futuristic, immersive. Designed for the bold.",
  authors: [{ name: "BILAL GARMENTS" }],
  themeColor: "#0a0a0a",
  openGraph: {
    title: "BILAL GARMENTS — Cinematic Luxury Fashion",
    description:
      "Premium Pakistani fashion. Cinematic, futuristic, immersive. Designed for the bold.",
    type: "website",
    images: [
      "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/94f560a2-0fff-4f83-8f4e-e74f8896ca14/id-preview-9a75eb5b--7dbd9483-d0a7-43ae-b745-e61a689b78e2.lovable.app-1778656689143.png",
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "BILAL GARMENTS — Cinematic Luxury Fashion",
    description:
      "Premium Pakistani fashion. Cinematic, futuristic, immersive. Designed for the bold.",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />
        <link
          rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=Italiana&family=Inter+Tight:wght@300;400;500;600;700;800&display=swap"
        />
      </head>
      <body>
        <AdminProvider>
          <StoreProvider>
            <AmbientBackground />
            {children}
            <Toaster
              theme="dark"
              position="bottom-right"
              toastOptions={{
                style: {
                  background: "oklch(0.10 0 0 / 0.85)",
                  backdropFilter: "blur(20px)",
                  border: "1px solid oklch(1 0 0 / 0.10)",
                  color: "oklch(0.97 0 0)",
                },
              }}
            />
          </StoreProvider>
        </AdminProvider>
      </body>
    </html>
  );
}
