"use client";

import { useEffect } from "react";
import { useAdmin } from "@/lib/admin-store";
import { fmtPKR } from "@/lib/products";
import {
  Bar, BarChart, CartesianGrid, Cell, Legend,
  Pie, PieChart, ResponsiveContainer, Tooltip,
  XAxis, YAxis,
} from "recharts";
import { RefreshCw, TrendingUp } from "lucide-react";

const COLORS = [
  "oklch(0.62 0.24 25)",
  "oklch(0.70 0.18 60)",
  "oklch(0.65 0.18 280)",
  "oklch(0.70 0.18 160)",
  "oklch(0.65 0.18 200)",
];
const tipStyle = {
  background: "oklch(0.10 0 0 / 0.95)",
  border: "1px solid oklch(1 0 0 / 0.1)",
  borderRadius: 12,
  fontSize: 12,
};

function Card({ title, loading, children }: { title: string; loading?: boolean; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-[oklch(0.09_0_0)]/80 backdrop-blur-xl p-5 lg:p-6">
      <h3 className="font-medium mb-4">{title}</h3>
      {loading
        ? <div className="h-64 w-full rounded-xl bg-white/5 animate-pulse" />
        : children
      }
    </div>
  );
}

export default function AnalyticsPage() {
  const { analytics, analyticsLoading, fetchAnalytics } = useAdmin();

  useEffect(() => { fetchAnalytics(); }, [fetchAnalytics]);

  const a = analytics;

  return (
    <div className="space-y-5 max-w-7xl">
      <div className="flex items-start justify-between">
        <div>
          <h2 className="font-display text-3xl lg:text-4xl tracking-wide">Analytics</h2>
          <p className="text-sm text-muted-foreground mt-1">Store performance insights</p>
        </div>
        <button
          onClick={fetchAnalytics}
          className="flex items-center gap-2 px-3 py-2 rounded-lg border border-white/10 bg-white/5 hover:bg-white/10 text-sm"
        >
          <RefreshCw className={`h-4 w-4 ${analyticsLoading ? "animate-spin" : ""}`} />
          Refresh
        </button>
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <Card title="Revenue by Category" loading={analyticsLoading}>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={a?.by_category ?? []} dataKey="revenue" nameKey="name" outerRadius={90} innerRadius={55} paddingAngle={3}>
                  {(a?.by_category ?? []).map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip contentStyle={tipStyle} formatter={(v: number) => [fmtPKR(v), "Revenue"]} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card title="Orders by Status" loading={analyticsLoading}>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={a?.by_status ?? []}>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 0.06)" />
                <XAxis dataKey="name" tick={{ fontSize: 10, fill: "oklch(0.62 0 0)" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: "oklch(0.62 0 0)" }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={tipStyle} />
                <Bar dataKey="value" fill="oklch(0.62 0.24 25)" radius={[8,8,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>

      <Card title="Monthly Revenue — Last 6 Months" loading={analyticsLoading}>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={a?.monthly ?? []}>
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 0.06)" />
              <XAxis dataKey="name" tick={{ fontSize: 11, fill: "oklch(0.62 0 0)" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "oklch(0.62 0 0)" }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={tipStyle} formatter={(v: number) => [fmtPKR(v), "Revenue"]} />
              <Bar dataKey="revenue" fill="oklch(0.62 0.24 25)" radius={[8,8,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>

      <div className="grid lg:grid-cols-2 gap-4">
        <Card title="Top Products" loading={analyticsLoading}>
          <div className="space-y-2">
            {(a?.top_products ?? []).map((p, i) => (
              <div key={i} className="flex items-center gap-3 p-3 rounded-lg bg-white/[0.03]">
                <span className="h-7 w-7 rounded-full bg-primary/15 text-primary text-xs flex items-center justify-center font-semibold shrink-0">
                  {i + 1}
                </span>
                <div className="flex-1 min-w-0">
                  <p className="text-sm truncate">{p.name}</p>
                  <p className="text-[11px] text-muted-foreground">{p.qty} sold</p>
                </div>
                <span className="text-sm font-medium shrink-0">{fmtPKR(p.revenue)}</span>
              </div>
            ))}
            {(!a || a.top_products.length === 0) && (
              <p className="text-sm text-muted-foreground text-center py-4">No data yet</p>
            )}
          </div>
        </Card>

        <Card title="Sales by City" loading={analyticsLoading}>
          <div className="space-y-2">
            {(a?.by_city ?? []).map((c, i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-white/[0.03]">
                <div>
                  <p className="text-sm font-medium">{c.name}</p>
                  <p className="text-[11px] text-muted-foreground">{c.orders} orders</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-primary">{fmtPKR(c.revenue)}</p>
                  <TrendingUp className="h-3 w-3 text-muted-foreground ml-auto mt-0.5" />
                </div>
              </div>
            ))}
            {(!a || a.by_city.length === 0) && (
              <p className="text-sm text-muted-foreground text-center py-4">No data yet</p>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
}
