"use client";

import { useEffect, useState } from "react";
import { useAdmin, type ApiOrder, type OrderStatus } from "@/lib/admin-store";
import { fmtPKR } from "@/lib/products";
import { StatusBadge } from "@/app/admin/page";
import { Search, Eye, Trash2, X, Download, RefreshCw, Clock, ChevronLeft, ChevronRight } from "lucide-react";
import { toast } from "sonner";

const STATUS_FILTERS: (OrderStatus | "All")[] = ["All","Pending","Processing","Shipped","Delivered","Cancelled"];

function OrderDrawer({ order, onClose, onStatusChange }: {
  order: ApiOrder; onClose: () => void;
  onStatusChange: (s: OrderStatus) => void;
}) {
  return (
    <div className="fixed inset-0 z-50 flex">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
      <div className="relative ml-auto w-full max-w-lg h-full bg-[oklch(0.09_0_0)] border-l border-white/10 overflow-y-auto p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="font-display text-2xl">{order.order_no}</h3>
            <p className="text-xs text-muted-foreground mt-1">
              {new Date(order.created_at).toLocaleString()}
            </p>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-white/10">
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="space-y-6">
          {/* Customer */}
          <section>
            <p className="text-[11px] uppercase tracking-wider text-muted-foreground mb-2">Customer</p>
            <div className="p-4 rounded-xl bg-white/[0.03] space-y-1">
              <p className="font-medium">{order.customer_name}</p>
              {order.customer_email && <p className="text-xs text-muted-foreground">{order.customer_email}</p>}
              <p className="text-xs text-muted-foreground">{order.customer_phone}</p>
              <p className="text-xs text-muted-foreground">{order.address}, {order.city}</p>
              {order.notes && (
                <p className="text-xs text-foreground/70 border-t border-white/10 pt-2 mt-2">
                  📝 {order.notes}
                </p>
              )}
            </div>
          </section>

          {/* Status */}
          <section>
            <p className="text-[11px] uppercase tracking-wider text-muted-foreground mb-2">Update Status</p>
            <div className="grid grid-cols-3 gap-1.5">
              {(["Pending","Processing","Shipped","Delivered","Cancelled"] as OrderStatus[]).map((s) => (
                <button
                  key={s}
                  onClick={() => onStatusChange(s)}
                  className={`px-2 py-2 text-xs rounded-lg border transition-all ${
                    order.status === s
                      ? "bg-primary/15 border-primary/30 text-primary"
                      : "bg-white/[0.03] border-white/10 hover:bg-white/[0.08]"
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </section>

          {/* Items */}
          {order.items && order.items.length > 0 && (
            <section>
              <p className="text-[11px] uppercase tracking-wider text-muted-foreground mb-2">
                Items ({order.items.length})
              </p>
              <div className="space-y-2">
                {order.items.map((it, i) => (
                  <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-white/[0.03]">
                    <div className="min-w-0">
                      <p className="text-sm truncate">{it.name}</p>
                      <p className="text-[11px] text-muted-foreground">
                        Qty {it.qty} × {fmtPKR(it.price)}
                        {it.size && ` · Size ${it.size}`}
                      </p>
                    </div>
                    <span className="text-sm font-medium shrink-0">{fmtPKR(it.total)}</span>
                  </div>
                ))}
              </div>
            </section>
          )}

          {/* Totals */}
          <section className="border-t border-white/10 pt-4 space-y-2">
            <div className="flex justify-between text-sm text-muted-foreground">
              <span>Subtotal</span><span>{fmtPKR(order.subtotal)}</span>
            </div>
            <div className="flex justify-between text-sm text-muted-foreground">
              <span>Shipping</span><span>{order.shipping === 0 ? "Free" : fmtPKR(order.shipping)}</span>
            </div>
            {order.tax > 0 && (
              <div className="flex justify-between text-sm text-muted-foreground">
                <span>Tax</span><span>{fmtPKR(order.tax)}</span>
              </div>
            )}
            <div className="flex justify-between items-baseline pt-2 border-t border-white/10">
              <span className="text-sm text-muted-foreground">Total</span>
              <span className="font-display text-2xl">{fmtPKR(order.total)}</span>
            </div>
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>Payment</span><span className="text-foreground">{order.payment}</span>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}

export default function OrdersPage() {
  const { orders, ordersLoading, ordersPagination, fetchOrders, updateOrderStatus, deleteOrder } = useAdmin();
  const [q, setQ]           = useState("");
  const [filter, setFilter] = useState<OrderStatus | "All">("All");
  const [page, setPage]     = useState(1);
  const [view, setView]     = useState<ApiOrder | null>(null);
  const [loadingDetail, setLoadingDetail] = useState(false);

  useEffect(() => {
    const params: Record<string, string | number> = { page };
    if (filter !== "All") params.status = filter;
    if (q) params.search = q;
    fetchOrders(params);
  }, [filter, page, fetchOrders]);

  // Debounced search
  useEffect(() => {
    if (!q) return;
    const t = setTimeout(() => {
      setPage(1);
      fetchOrders({ page: 1, search: q, ...(filter !== "All" ? { status: filter } : {}) });
    }, 400);
    return () => clearTimeout(t);
  }, [q]);

  const exportCsv = () => {
    const rows = [["ID","Order No","Customer","Email","Phone","City","Total","Status","Payment","Date"]];
    orders.forEach((o) =>
      rows.push([
        String(o.id), o.order_no, o.customer_name, o.customer_email,
        o.customer_phone, o.city, String(o.total), o.status, o.payment,
        new Date(o.created_at).toLocaleDateString(),
      ])
    );
    const csv  = rows.map((r) => r.map((c) => `"${c}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement("a");
    a.href = url; a.download = `orders-${Date.now()}.csv`; a.click();
    URL.revokeObjectURL(url);
    toast.success("CSV exported");
  };

  const handleViewOrder = async (o: ApiOrder) => {
    // If items already loaded just open
    if (o.items) { setView(o); return; }
    setLoadingDetail(true);
    try {
      const { adminApi } = await import("@/lib/api");
      const res = await adminApi.getOrder(o.id);
      setView(res.data);
    } catch { toast.error("Failed to load order details"); }
    finally { setLoadingDetail(false); }
  };

  return (
    <div className="space-y-5 max-w-7xl">
      {/* Header */}
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <h2 className="font-display text-3xl lg:text-4xl tracking-wide">Orders</h2>
          <p className="text-sm text-muted-foreground mt-1">
            {ordersPagination ? `${ordersPagination.total} total orders` : "Loading…"}
          </p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => fetchOrders({ page, ...(filter !== "All" ? { status: filter } : {}) })}
            className="flex items-center gap-2 px-3 py-2 rounded-lg border border-white/10 bg-white/5 hover:bg-white/10 text-sm transition-colors"
          >
            <RefreshCw className={`h-4 w-4 ${ordersLoading ? "animate-spin" : ""}`} />
          </button>
          <button
            onClick={exportCsv}
            className="flex items-center gap-2 px-4 py-2 rounded-lg border border-white/10 bg-white/5 hover:bg-white/10 text-sm transition-colors"
          >
            <Download className="h-4 w-4" /> Export CSV
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col gap-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search order ID or customer…"
            className="w-full pl-10 pr-3 py-2 rounded-lg bg-white/5 border border-white/10 text-sm focus:border-primary/50 focus:outline-none"
          />
        </div>
        <div className="flex gap-1.5 overflow-x-auto pb-1">
          {STATUS_FILTERS.map((f) => (
            <button
              key={f}
              onClick={() => { setFilter(f); setPage(1); }}
              className={`px-3 py-1.5 text-xs rounded-lg border whitespace-nowrap transition-all ${
                filter === f
                  ? "bg-primary/15 border-primary/30 text-primary"
                  : "bg-white/[0.03] border-white/10 hover:bg-white/[0.08]"
              }`}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {/* Orders list */}
      <div className="space-y-2">
        {ordersLoading ? (
          [...Array(6)].map((_, i) => (
            <div key={i} className="h-20 rounded-xl bg-white/5 animate-pulse" />
          ))
        ) : orders.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground">
            <ShoppingBagEmpty />
            <p className="text-sm mt-2">No orders found</p>
          </div>
        ) : orders.map((o) => (
          <div
            key={o.id}
            className="p-4 rounded-xl border border-white/10 bg-[oklch(0.09_0_0)]/80 backdrop-blur-xl hover:border-white/20 transition-all"
          >
            <div className="flex items-start justify-between gap-3 flex-wrap">
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-medium text-sm">{o.order_no}</span>
                  <StatusBadge status={o.status} />
                  <span className="text-[10px] text-muted-foreground px-2 py-0.5 rounded-full bg-white/5">
                    {o.payment}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground mt-1">
                  {o.customer_name} · {o.city}
                </p>
                <p className="text-[11px] text-muted-foreground/70 mt-0.5 flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  {new Date(o.created_at).toLocaleString()} · {o.item_count} item{Number(o.item_count) !== 1 ? "s" : ""}
                </p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <span className="font-medium">{fmtPKR(o.total)}</span>
                <button
                  onClick={() => handleViewOrder(o)}
                  disabled={loadingDetail}
                  className="p-2 rounded-lg hover:bg-white/10 transition-colors"
                >
                  <Eye className="h-4 w-4" />
                </button>
                <button
                  onClick={() => {
                    if (confirm(`Delete order ${o.order_no}?`)) deleteOrder(o.id);
                  }}
                  className="p-2 rounded-lg hover:bg-destructive/15 hover:text-destructive transition-colors"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Pagination */}
      {ordersPagination && ordersPagination.total_pages > 1 && (
        <div className="flex items-center justify-between pt-2">
          <p className="text-xs text-muted-foreground">
            Page {ordersPagination.page} of {ordersPagination.total_pages}
          </p>
          <div className="flex gap-1.5">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
              className="p-2 rounded-lg border border-white/10 hover:bg-white/10 disabled:opacity-40 transition-colors"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <button
              onClick={() => setPage((p) => Math.min(ordersPagination.total_pages, p + 1))}
              disabled={page === ordersPagination.total_pages}
              className="p-2 rounded-lg border border-white/10 hover:bg-white/10 disabled:opacity-40 transition-colors"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}

      {/* Drawer */}
      {view && (
        <OrderDrawer
          order={view}
          onClose={() => setView(null)}
          onStatusChange={async (s) => {
            await updateOrderStatus(view.id, s);
            setView({ ...view, status: s });
          }}
        />
      )}
    </div>
  );
}

function ShoppingBagEmpty() {
  return (
    <div className="mx-auto h-12 w-12 rounded-full bg-white/5 flex items-center justify-center mb-2">
      <Search className="h-5 w-5 text-muted-foreground" />
    </div>
  );
}
