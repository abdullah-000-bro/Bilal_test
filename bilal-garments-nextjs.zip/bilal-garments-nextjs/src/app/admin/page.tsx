"use client";

import Link from "next/link";
import { useEffect } from "react";
import { useAdmin } from "@/lib/admin-store";
import { fmtPKR } from "@/lib/products";
import {
  ShoppingBag, Users, Package, DollarSign,
  TrendingUp, ArrowUpRight, Clock, AlertTriangle,
  RefreshCw,
} from "lucide-react";
import {
  Area, AreaChart, ResponsiveContainer, Tooltip,
  XAxis, YAxis, CartesianGrid,
} from "recharts";

export function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    Pending:    "bg-amber-500/15 text-amber-300 border-amber-500/30",
    Processing: "bg-blue-500/15 text-blue-300 border-blue-500/30",
    Shipped:    "bg-purple-500/15 text-purple-300 border-purple-500/30",
    Delivered:  "bg-emerald-500/15 text-emerald-300 border-emerald-500/30",
    Cancelled:  "bg-red-500/15 text-red-300 border-red-500/30",
  };
  return (
    <span className={`text-[10px] px-2 py-0.5 rounded-full border ${map[status] ?? "bg-white/10"}`}>
      {status}
    </span>
  );
}

function StatCard({ label, value, icon: Icon, sub, accent, loading }: {
  label: string; value: string; icon: React.ElementType;
  sub?: string; accent?: boolean; loading?: boolean;
}) {
  return (
    <div className={`rounded-2xl border p-4 lg:p-5 backdrop-blur-xl transition-all hover:-translate-y-0.5 ${
      accent
        ? "border-primary/30 bg-gradient-to-br from-primary/15 to-transparent"
        : "border-white/10 bg-[oklch(0.09_0_0)]/80"
    }`}>
      <div className="flex items-start justify-between">
        <div className={`h-9 w-9 rounded-lg flex items-center justify-center ${
          accent ? "bg-primary/20 text-primary" : "bg-white/5 text-muted-foreground"
        }`}>
          <Icon className="h-4 w-4" />
        </div>
        {sub && <span className="text-[10px] text-muted-foreground">{sub}</span>}
      </div>
      <p className="text-xs text-muted-foreground mt-3">{label}</p>
      {loading
        ? <div className="h-7 w-28 rounded-lg bg-white/5 animate-pulse mt-1" />
        : <p className="text-xl lg:text-2xl font-semibold mt-1 truncate">{value}</p>
      }
    </div>
  );
}

const tipStyle = {
  background: "oklch(0.10 0 0 / 0.95)",
  border: "1px solid oklch(1 0 0 / 0.1)",
  borderRadius: 12,
  fontSize: 12,
};

export default function AdminDashboard() {
  const { dashboard, dashboardLoading, fetchDashboard } = useAdmin();

  useEffect(() => { fetchDashboard(); }, [fetchDashboard]);

  const s = dashboard?.stats;
  const chart = dashboard?.chart ?? [];
  const recent = dashboard?.recent ?? [];

  return (
    <div className="space-y-6 max-w-7xl">
      <div className="flex items-start justify-between">
        <div>
          <h2 className="font-display text-3xl lg:text-4xl tracking-wide">Dashboard</h2>
          <p className="text-sm text-muted-foreground mt-1">Store overview at a glance</p>
        </div>
        <button
          onClick={fetchDashboard}
          className="flex items-center gap-2 px-3 py-2 rounded-lg border border-white/10 bg-white/5 hover:bg-white/10 text-sm transition-colors"
        >
          <RefreshCw className={`h-4 w-4 ${dashboardLoading ? "animate-spin" : ""}`} />
          Refresh
        </button>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4">
        <StatCard
          label="Total Revenue" accent
          value={s ? fmtPKR(s.revenue) : "—"}
          sub={s ? `+${fmtPKR(s.revenue_today)} today` : undefined}
          icon={DollarSign} loading={dashboardLoading}
        />
        <StatCard
          label="Total Orders"
          value={s ? String(s.total_orders) : "—"}
          sub={s ? `${s.orders_today} today` : undefined}
          icon={ShoppingBag} loading={dashboardLoading}
        />
        <StatCard
          label="Customers"
          value={s ? String(s.customers) : "—"}
          icon={Users} loading={dashboardLoading}
        />
        <StatCard
          label="Active Products"
          value={s ? String(s.products) : "—"}
          sub={s?.low_stock ? `⚠ ${s.low_stock} low stock` : undefined}
          icon={Package} loading={dashboardLoading}
        />
      </div>

      {/* Low stock alert */}
      {s && s.low_stock > 0 && (
        <div className="flex items-center gap-3 p-4 rounded-xl border border-amber-500/30 bg-amber-500/10 text-sm">
          <AlertTriangle className="h-4 w-4 text-amber-400 shrink-0" />
          <span className="text-amber-200">
            {s.low_stock} product{s.low_stock > 1 ? "s are" : " is"} low on stock (less than 5 units).{" "}
          </span>
          <Link href="/admin/products" className="text-amber-300 hover:underline ml-auto shrink-0">
            View products →
          </Link>
        </div>
      )}

      {/* Pending orders badge */}
      {s && s.pending_orders > 0 && (
        <div className="flex items-center gap-3 p-4 rounded-xl border border-blue-500/30 bg-blue-500/10 text-sm">
          <Clock className="h-4 w-4 text-blue-400 shrink-0" />
          <span className="text-blue-200">
            {s.pending_orders} order{s.pending_orders > 1 ? "s" : ""} waiting for processing.
          </span>
          <Link href="/admin/orders?status=Pending" className="text-blue-300 hover:underline ml-auto shrink-0">
            Process now →
          </Link>
        </div>
      )}

      {/* Revenue chart */}
      <div className="rounded-2xl border border-white/10 bg-[oklch(0.09_0_0)]/80 backdrop-blur-xl p-5 lg:p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="font-medium">Revenue — Last 14 days</h3>
            <p className="text-xs text-muted-foreground mt-0.5">Daily performance</p>
          </div>
          <TrendingUp className="h-5 w-5 text-primary" />
        </div>
        {dashboardLoading ? (
          <div className="h-64 w-full rounded-xl bg-white/5 animate-pulse" />
        ) : (
          <div className="h-64 sm:h-72 -ml-2">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chart}>
                <defs>
                  <linearGradient id="rev" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%"  stopColor="oklch(0.62 0.24 25)" stopOpacity={0.5} />
                    <stop offset="95%" stopColor="oklch(0.62 0.24 25)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 0.06)" />
                <XAxis dataKey="label" tick={{ fontSize: 11, fill: "oklch(0.62 0 0)" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: "oklch(0.62 0 0)" }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={tipStyle}
                  formatter={(v: number) => [fmtPKR(v), "Revenue"]}
                />
                <Area type="monotone" dataKey="revenue" stroke="oklch(0.62 0.24 25)" strokeWidth={2} fill="url(#rev)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      {/* Recent orders */}
      <div className="rounded-2xl border border-white/10 bg-[oklch(0.09_0_0)]/80 backdrop-blur-xl p-5 lg:p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-medium">Recent Orders</h3>
          <Link href="/admin/orders" className="text-xs text-primary hover:underline flex items-center gap-1">
            View all <ArrowUpRight className="h-3 w-3" />
          </Link>
        </div>
        {dashboardLoading ? (
          <div className="space-y-2">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="h-14 rounded-lg bg-white/5 animate-pulse" />
            ))}
          </div>
        ) : recent.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-8">No orders yet.</p>
        ) : (
          <div className="space-y-2">
            {recent.map((o) => (
              <div key={o.id} className="flex items-center justify-between p-3 rounded-lg bg-white/[0.03] hover:bg-white/[0.06] transition-colors">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-medium truncate">{o.customer_name}</span>
                    <StatusBadge status={o.status} />
                  </div>
                  <p className="text-[11px] text-muted-foreground mt-0.5 flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {o.order_no} · {new Date(o.created_at).toLocaleDateString()}
                  </p>
                </div>
                <div className="text-sm font-medium shrink-0">{fmtPKR(o.total)}</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
