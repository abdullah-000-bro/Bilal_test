"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useAdmin } from "@/lib/admin-store";
import { Lock, User, Sparkles, Eye, EyeOff } from "lucide-react";

export default function AdminLoginPage() {
  const { login, isAuthed, loading } = useAdmin();
  const router = useRouter();
  const [u, setU]         = useState("admin");
  const [p, setP]         = useState("");
  const [showPw, setShowPw] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!loading && isAuthed) router.replace("/admin");
  }, [isAuthed, loading, router]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSubmitting(true);
    const ok = await login(u, p);
    if (ok) {
      router.replace("/admin");
    } else {
      setError("Invalid username or password. Try admin / admin123");
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 relative overflow-hidden">
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_top,oklch(0.18_0.01_20)_0%,oklch(0.06_0_0)_70%)]" />
      <div className="absolute inset-0 -z-10 opacity-30 bg-[radial-gradient(circle_at_30%_20%,oklch(0.58_0.22_25/0.3),transparent_50%)]" />

      <form
        onSubmit={submit}
        className="w-full max-w-md p-8 rounded-2xl border border-white/10 bg-[oklch(0.10_0_0)]/80 backdrop-blur-2xl shadow-2xl"
      >
        <div className="flex items-center justify-center gap-2 mb-2">
          <Sparkles className="h-5 w-5 text-primary" />
          <span className="font-display text-2xl tracking-wider">BG Admin</span>
        </div>
        <p className="text-center text-xs text-muted-foreground mb-8">
          Sign in to manage your store
        </p>

        {error && (
          <div className="mb-4 px-4 py-3 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-300">
            {error}
          </div>
        )}

        <label className="block text-xs text-muted-foreground mb-2">Username</label>
        <div className="relative mb-4">
          <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            value={u}
            onChange={(e) => setU(e.target.value)}
            className="w-full pl-10 pr-3 py-2.5 rounded-lg bg-white/5 border border-white/10 focus:border-primary/50 focus:outline-none text-sm transition-colors"
            placeholder="admin"
            autoComplete="username"
          />
        </div>

        <label className="block text-xs text-muted-foreground mb-2">Password</label>
        <div className="relative mb-6">
          <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            type={showPw ? "text" : "password"}
            value={p}
            onChange={(e) => setP(e.target.value)}
            className="w-full pl-10 pr-10 py-2.5 rounded-lg bg-white/5 border border-white/10 focus:border-primary/50 focus:outline-none text-sm transition-colors"
            placeholder="••••••••"
            autoComplete="current-password"
          />
          <button
            type="button"
            onClick={() => setShowPw((v) => !v)}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
          >
            {showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
          </button>
        </div>

        <button
          type="submit"
          disabled={submitting}
          className="w-full py-2.5 rounded-lg bg-primary text-primary-foreground font-medium text-sm hover:bg-primary/90 transition-all disabled:opacity-60 flex items-center justify-center gap-2"
        >
          {submitting ? (
            <><span className="h-4 w-4 rounded-full border-2 border-white/30 border-t-white animate-spin" /> Signing in…</>
          ) : "Sign In"}
        </button>

        <p className="mt-6 text-center text-[11px] text-muted-foreground">
          Demo credentials:{" "}
          <button type="button" onClick={() => { setU("admin"); setP("admin123"); }} className="text-foreground/80 hover:text-primary underline">
            admin / admin123
          </button>
        </p>
      </form>
    </div>
  );
}
