"use client";

import { useEffect, useState } from "react";
import { useAdmin, type ApiSettings } from "@/lib/admin-store";
import { Save, RefreshCw } from "lucide-react";

const inputCls =
  "w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-sm focus:border-primary/50 focus:outline-none transition-colors";

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="block text-xs text-muted-foreground mb-1.5">{label}</span>
      {children}
    </label>
  );
}

export default function SettingsPage() {
  const { settings, settingsLoading, fetchSettings, saveSettings } = useAdmin();
  const [form, setForm]     = useState<Partial<ApiSettings>>({});
  const [saving, setSaving] = useState(false);

  useEffect(() => { fetchSettings(); }, [fetchSettings]);
  useEffect(() => { if (settings) setForm(settings); }, [settings]);

  const set = (k: string, v: unknown) => setForm((f) => ({ ...f, [k]: v }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try { await saveSettings(form); }
    finally { setSaving(false); }
  };

  return (
    <div className="space-y-5 max-w-3xl">
      <div className="flex items-start justify-between">
        <div>
          <h2 className="font-display text-3xl lg:text-4xl tracking-wide">Settings</h2>
          <p className="text-sm text-muted-foreground mt-1">Configure your store preferences</p>
        </div>
        <button
          onClick={fetchSettings}
          className="p-2.5 rounded-lg border border-white/10 bg-white/5 hover:bg-white/10 transition-colors"
        >
          <RefreshCw className={`h-4 w-4 ${settingsLoading ? "animate-spin" : ""}`} />
        </button>
      </div>

      {settingsLoading && !settings ? (
        <div className="space-y-4">
          {[...Array(4)].map((_, i) => <div key={i} className="h-16 rounded-xl bg-white/5 animate-pulse" />)}
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Store info */}
          <div className="rounded-2xl border border-white/10 bg-[oklch(0.09_0_0)]/80 backdrop-blur-xl p-5 lg:p-6 space-y-4">
            <h3 className="font-medium">Store Information</h3>
            <Field label="Store Name">
              <input value={form.store_name ?? ""} onChange={(e) => set("store_name", e.target.value)} className={inputCls} />
            </Field>
            <div className="grid sm:grid-cols-2 gap-3">
              <Field label="Email">
                <input type="email" value={form.email ?? ""} onChange={(e) => set("email", e.target.value)} className={inputCls} />
              </Field>
              <Field label="Phone">
                <input value={form.phone ?? ""} onChange={(e) => set("phone", e.target.value)} className={inputCls} />
              </Field>
            </div>
            <Field label="Address">
              <input value={form.address ?? ""} onChange={(e) => set("address", e.target.value)} className={inputCls} />
            </Field>
          </div>

          {/* Commerce settings */}
          <div className="rounded-2xl border border-white/10 bg-[oklch(0.09_0_0)]/80 backdrop-blur-xl p-5 lg:p-6 space-y-4">
            <h3 className="font-medium">Commerce</h3>
            <div className="grid sm:grid-cols-3 gap-3">
              <Field label="Currency">
                <input value={form.currency ?? ""} onChange={(e) => set("currency", e.target.value)} className={inputCls} />
              </Field>
              <Field label="Free Shipping Over (PKR)">
                <input type="number" min={0} value={form.free_shipping_over ?? 0} onChange={(e) => set("free_shipping_over", +e.target.value)} className={inputCls} />
              </Field>
              <Field label="Flat Shipping (PKR)">
                <input type="number" min={0} value={form.shipping_flat ?? 0} onChange={(e) => set("shipping_flat", +e.target.value)} className={inputCls} />
              </Field>
            </div>
            <Field label="Tax %">
              <input type="number" min={0} max={100} step={0.01} value={form.tax_pct ?? 0} onChange={(e) => set("tax_pct", +e.target.value)} className={inputCls + " max-w-xs"} />
            </Field>
          </div>

          {/* Maintenance */}
          <div className="rounded-2xl border border-white/10 bg-[oklch(0.09_0_0)]/80 backdrop-blur-xl p-5 lg:p-6">
            <h3 className="font-medium mb-4">Store Status</h3>
            <label className="flex items-start gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={!!form.maintenance}
                onChange={(e) => set("maintenance", e.target.checked)}
                className="h-4 w-4 mt-0.5 accent-[oklch(0.62_0.24_25)]"
              />
              <div>
                <p className="text-sm font-medium">Maintenance Mode</p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Show a coming-soon page to visitors while you make updates.
                </p>
              </div>
            </label>
          </div>

          <button
            type="submit"
            disabled={saving}
            className="flex items-center gap-2 px-6 py-2.5 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors disabled:opacity-60"
          >
            {saving ? (
              <><span className="h-3.5 w-3.5 rounded-full border-2 border-white/30 border-t-white animate-spin" /> Saving…</>
            ) : (
              <><Save className="h-4 w-4" /> Save Changes</>
            )}
          </button>
        </form>
      )}

      {/* API Info card */}
      <div className="rounded-2xl border border-white/10 bg-[oklch(0.09_0_0)]/80 backdrop-blur-xl p-5 lg:p-6">
        <h3 className="font-medium mb-2">API Connection</h3>
        <p className="text-sm text-muted-foreground mb-3">
          This admin panel is connected to the PHP REST API backend with MySQL database.
        </p>
        <div className="grid sm:grid-cols-2 gap-2 text-xs">
          {[
            ["API Base", process.env.NEXT_PUBLIC_API_URL ?? "http://localhost/bilal-garments-backend"],
            ["Auth", "JWT Bearer Token"],
            ["Database", "MySQL 5.7+ / MariaDB"],
            ["Storage", "MySQL (persistent)"],
          ].map(([k, v]) => (
            <div key={k} className="p-3 rounded-lg bg-white/[0.03]">
              <p className="text-muted-foreground">{k}</p>
              <p className="font-medium mt-0.5 truncate">{v}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
