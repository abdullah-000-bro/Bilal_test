"use client";

import { useEffect, useState } from "react";
import { useAdmin, type ApiCustomer } from "@/lib/admin-store";
import { fmtPKR } from "@/lib/products";
import { Search, Mail, Phone, MapPin, RefreshCw, ChevronLeft, ChevronRight } from "lucide-react";

export default function CustomersPage() {
  const { customers, customersLoading, fetchCustomers } = useAdmin();
  const [q, setQ]       = useState("");
  const [sort, setSort] = useState("total_spent");
  const [page, setPage] = useState(1);
  const PER_PAGE = 12;

  useEffect(() => {
    fetchCustomers({ sort, per_page: 100 });
  }, [sort, fetchCustomers]);

  const filtered = customers.filter(
    (c) => !q || c.name.toLowerCase().includes(q.toLowerCase()) || c.email.toLowerCase().includes(q.toLowerCase())
  );
  const paginated  = filtered.slice((page - 1) * PER_PAGE, page * PER_PAGE);
  const totalPages = Math.ceil(filtered.length / PER_PAGE);

  return (
    <div className="space-y-5 max-w-7xl">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <h2 className="font-display text-3xl lg:text-4xl tracking-wide">Customers</h2>
          <p className="text-sm text-muted-foreground mt-1">
            {customers.length} unique customers
          </p>
        </div>
        <button
          onClick={() => fetchCustomers({ sort })}
          className="p-2.5 rounded-lg border border-white/10 bg-white/5 hover:bg-white/10 transition-colors"
        >
          <RefreshCw className={`h-4 w-4 ${customersLoading ? "animate-spin" : ""}`} />
        </button>
      </div>

      {/* Search & sort */}
      <div className="flex flex-wrap gap-2">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            value={q}
            onChange={(e) => { setQ(e.target.value); setPage(1); }}
            placeholder="Search customers…"
            className="w-full pl-10 pr-3 py-2 rounded-lg bg-white/5 border border-white/10 text-sm focus:border-primary/50 focus:outline-none"
          />
        </div>
        <select
          value={sort}
          onChange={(e) => setSort(e.target.value)}
          className="px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-sm focus:outline-none"
        >
          <option value="total_spent">Highest Spend</option>
          <option value="orders">Most Orders</option>
          <option value="name">Name A–Z</option>
          <option value="created_at">Newest</option>
        </select>
      </div>

      {/* Grid */}
      {customersLoading ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="h-44 rounded-2xl bg-white/5 animate-pulse" />
          ))}
        </div>
      ) : paginated.length === 0 ? (
        <p className="text-center text-sm text-muted-foreground py-16">No customers found</p>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {paginated.map((c) => <CustomerCard key={c.id} c={c} />)}
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between pt-2">
          <p className="text-xs text-muted-foreground">
            {filtered.length} customers · page {page} of {totalPages}
          </p>
          <div className="flex gap-1.5">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
              className="p-2 rounded-lg border border-white/10 hover:bg-white/10 disabled:opacity-40"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
              className="p-2 rounded-lg border border-white/10 hover:bg-white/10 disabled:opacity-40"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function CustomerCard({ c }: { c: ApiCustomer }) {
  const initials = c.name.split(" ").map((s) => s[0]).slice(0, 2).join("");
  return (
    <div className="p-5 rounded-2xl border border-white/10 bg-[oklch(0.09_0_0)]/80 backdrop-blur-xl hover:border-primary/30 transition-all hover:-translate-y-0.5">
      <div className="flex items-center gap-3 mb-3">
        <div className="h-11 w-11 rounded-full bg-gradient-to-br from-primary/30 to-primary/10 border border-primary/30 flex items-center justify-center text-sm font-semibold text-primary shrink-0">
          {initials}
        </div>
        <div className="min-w-0">
          <p className="font-medium text-sm truncate">{c.name}</p>
          <p className="text-[11px] text-muted-foreground">
            Joined {new Date(c.created_at).toLocaleDateString()}
          </p>
        </div>
      </div>
      <div className="space-y-1.5 text-xs text-muted-foreground mb-3">
        {c.email && (
          <p className="flex items-center gap-2 truncate">
            <Mail className="h-3 w-3 shrink-0" /> {c.email}
          </p>
        )}
        <p className="flex items-center gap-2">
          <Phone className="h-3 w-3 shrink-0" /> {c.phone}
        </p>
        {c.city && (
          <p className="flex items-center gap-2">
            <MapPin className="h-3 w-3 shrink-0" /> {c.city}
          </p>
        )}
      </div>
      <div className="grid grid-cols-2 gap-2 pt-3 border-t border-white/10">
        <div>
          <p className="text-[10px] text-muted-foreground uppercase tracking-wide">Orders</p>
          <p className="font-medium text-sm">{c.total_orders}</p>
        </div>
        <div>
          <p className="text-[10px] text-muted-foreground uppercase tracking-wide">Spent</p>
          <p className="font-medium text-sm text-primary">{fmtPKR(c.total_spent)}</p>
        </div>
      </div>
    </div>
  );
}
