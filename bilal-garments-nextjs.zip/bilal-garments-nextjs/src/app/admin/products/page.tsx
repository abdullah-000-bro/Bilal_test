"use client";

import { useEffect, useState } from "react";
import { useAdmin, type ApiProduct, CATEGORIES } from "@/lib/admin-store";
import { adminApi } from "@/lib/api";
import { fmtPKR } from "@/lib/products";
import { Plus, Search, Pencil, Trash2, X, Package, Upload, RefreshCw } from "lucide-react";
import Image from "next/image";
import { toast } from "sonner";

const inputCls =
  "w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-sm focus:border-primary/50 focus:outline-none transition-colors";

function Field({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="block text-xs text-muted-foreground mb-1.5">
        {label}{required && <span className="text-primary"> *</span>}
      </span>
      {children}
    </label>
  );
}

const EMPTY_FORM: Partial<ApiProduct> = {
  name: "", sku: "", description: "", price: 0, sale_price: undefined,
  category: "Men", tag: "", img: "", stock: 0,
};

function ProductDrawer({
  product, onClose, onSave,
}: {
  product: ApiProduct | null;
  onClose: () => void;
  onSave: (data: Partial<ApiProduct>) => Promise<void>;
}) {
  const [form, setForm]       = useState<Partial<ApiProduct>>(product ?? EMPTY_FORM);
  const [saving, setSaving]   = useState(false);
  const [uploading, setUploading] = useState(false);

  const set = (k: string, v: unknown) => setForm((f) => ({ ...f, [k]: v }));

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const url = await adminApi.uploadImage(file);
      set("img", url);
      toast.success("Image uploaded");
    } catch {
      toast.error("Upload failed");
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await onSave(form);
      onClose();
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Save failed");
    } finally {
      setSaving(false);
    }
  };

  // Category → category_id mapping (must match DB)
  const catIdMap: Record<string, number> = { Men: 1, Boys: 2, Kids: 3 };

  return (
    <div className="fixed inset-0 z-50 flex">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
      <div className="relative ml-auto w-full max-w-lg h-full bg-[oklch(0.09_0_0)] border-l border-white/10 overflow-y-auto p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="font-display text-2xl">{product ? "Edit Product" : "New Product"}</h3>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-white/10"><X className="h-4 w-4" /></button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <Field label="Product Name" required>
            <input required value={form.name ?? ""} onChange={(e) => set("name", e.target.value)} className={inputCls} placeholder="Onyx Mandarin Kurta" />
          </Field>

          <div className="grid grid-cols-2 gap-3">
            <Field label="SKU" required>
              <input required value={form.sku ?? ""} onChange={(e) => set("sku", e.target.value)} className={inputCls} placeholder="BG-001" />
            </Field>
            <Field label="Category">
              <select
                value={form.category ?? "Men"}
                onChange={(e) => { set("category", e.target.value); set("category_id", catIdMap[e.target.value]); }}
                className={inputCls}
              >
                {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </Field>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <Field label="Price (PKR)" required>
              <input required type="number" min={0} value={form.price ?? 0} onChange={(e) => set("price", +e.target.value)} className={inputCls} />
            </Field>
            <Field label="Sale Price (optional)">
              <input type="number" min={0} value={form.sale_price ?? ""} onChange={(e) => set("sale_price", e.target.value ? +e.target.value : undefined)} className={inputCls} placeholder="Leave blank" />
            </Field>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <Field label="Stock">
              <input type="number" min={0} value={form.stock ?? 0} onChange={(e) => set("stock", +e.target.value)} className={inputCls} />
            </Field>
            <Field label="Tag">
              <select value={form.tag ?? ""} onChange={(e) => set("tag", e.target.value)} className={inputCls}>
                <option value="">None</option>
                <option value="New">New</option>
                <option value="Trending">Trending</option>
                <option value="Limited">Limited</option>
              </select>
            </Field>
          </div>

          <Field label="Description">
            <textarea value={form.description ?? ""} onChange={(e) => set("description", e.target.value)} rows={3} className={inputCls} />
          </Field>

          {/* Image */}
          <Field label="Product Image">
            <div className="space-y-2">
              <input value={form.img ?? ""} onChange={(e) => set("img", e.target.value)} className={inputCls} placeholder="/assets/p1.jpg or https://…" />
              <label className={`flex items-center gap-2 px-3 py-2 rounded-lg border border-dashed border-white/20 hover:border-white/40 cursor-pointer text-xs text-muted-foreground transition-colors ${uploading ? "opacity-50 pointer-events-none" : ""}`}>
                <Upload className="h-3.5 w-3.5" />
                {uploading ? "Uploading…" : "Or upload from device"}
                <input type="file" accept="image/*" className="hidden" onChange={handleUpload} />
              </label>
              {form.img && (
                <div className="relative h-24 w-24 rounded-lg overflow-hidden bg-white/5">
                  <Image src={form.img} alt="Preview" fill className="object-cover" />
                </div>
              )}
            </div>
          </Field>

          <div className="flex gap-2 pt-4">
            <button type="button" onClick={onClose} className="flex-1 py-2.5 rounded-lg border border-white/10 hover:bg-white/5 text-sm transition-colors">
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="flex-1 py-2.5 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors disabled:opacity-60 flex items-center justify-center gap-2"
            >
              {saving && <span className="h-3.5 w-3.5 rounded-full border-2 border-white/30 border-t-white animate-spin" />}
              {saving ? "Saving…" : "Save Product"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default function ProductsPage() {
  const { products, productsLoading, fetchProducts, createProduct, updateProduct, deleteProduct } = useAdmin();
  const [q, setQ]             = useState("");
  const [cat, setCat]         = useState("All");
  const [editing, setEditing] = useState<ApiProduct | null>(null);
  const [creating, setCreating] = useState(false);

  useEffect(() => { fetchProducts(); }, [fetchProducts]);

  const filtered = products.filter(
    (p) =>
      (cat === "All" || p.category === cat) &&
      (!q || p.name.toLowerCase().includes(q.toLowerCase()) || p.sku.toLowerCase().includes(q.toLowerCase()))
  );

  return (
    <div className="space-y-5 max-w-7xl">
      {/* Header */}
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <h2 className="font-display text-3xl lg:text-4xl tracking-wide">Products</h2>
          <p className="text-sm text-muted-foreground mt-1">{products.length} items in catalog</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={fetchProducts}
            className="p-2.5 rounded-lg border border-white/10 bg-white/5 hover:bg-white/10 transition-colors"
          >
            <RefreshCw className={`h-4 w-4 ${productsLoading ? "animate-spin" : ""}`} />
          </button>
          <button
            onClick={() => setCreating(true)}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-all"
          >
            <Plus className="h-4 w-4" /> Add Product
          </button>
        </div>
      </div>

      {/* Search & category filter */}
      <div className="flex flex-wrap gap-2 items-center">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search name or SKU…"
            className="w-full pl-10 pr-3 py-2 rounded-lg bg-white/5 border border-white/10 text-sm focus:border-primary/50 focus:outline-none"
          />
        </div>
        <div className="flex gap-1.5">
          {["All", ...CATEGORIES].map((c) => (
            <button
              key={c}
              onClick={() => setCat(c)}
              className={`px-3 py-2 text-xs rounded-lg border transition-all ${
                cat === c ? "bg-primary/15 border-primary/30 text-primary" : "bg-white/[0.03] border-white/10 hover:bg-white/[0.08]"
              }`}
            >
              {c}
            </button>
          ))}
        </div>
      </div>

      {/* Desktop table */}
      <div className="hidden md:block rounded-2xl border border-white/10 bg-[oklch(0.09_0_0)]/80 backdrop-blur-xl overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-white/10 text-xs text-muted-foreground">
              <th className="text-left p-4 font-medium">Product</th>
              <th className="text-left p-4 font-medium">SKU</th>
              <th className="text-left p-4 font-medium">Category</th>
              <th className="text-right p-4 font-medium">Price</th>
              <th className="text-right p-4 font-medium">Stock</th>
              <th className="text-right p-4 font-medium">Actions</th>
            </tr>
          </thead>
          <tbody>
            {productsLoading ? (
              [...Array(6)].map((_, i) => (
                <tr key={i} className="border-b border-white/5">
                  <td colSpan={6} className="p-3">
                    <div className="h-12 rounded-lg bg-white/5 animate-pulse" />
                  </td>
                </tr>
              ))
            ) : filtered.map((p) => (
              <tr key={p.id} className="border-b border-white/5 hover:bg-white/[0.03] transition-colors">
                <td className="p-3">
                  <div className="flex items-center gap-3">
                    <div className="relative h-12 w-12 rounded-lg overflow-hidden bg-white/5 shrink-0">
                      {p.img && <Image src={p.img} alt={p.name} fill className="object-cover" />}
                    </div>
                    <div className="min-w-0">
                      <p className="font-medium truncate max-w-[240px]">{p.name}</p>
                      {p.tag && <span className="text-[10px] text-primary">{p.tag}</span>}
                    </div>
                  </div>
                </td>
                <td className="p-4 text-muted-foreground text-xs">{p.sku}</td>
                <td className="p-4 text-xs">{p.category}</td>
                <td className="p-4 text-right">
                  <div>
                    {p.sale_price ? (
                      <>
                        <span className="text-primary">{fmtPKR(p.sale_price)}</span>
                        <span className="text-muted-foreground line-through ml-2 text-xs">{fmtPKR(p.price)}</span>
                      </>
                    ) : fmtPKR(p.price)}
                  </div>
                </td>
                <td className="p-4 text-right">
                  <span className={`text-xs px-2 py-0.5 rounded-full ${
                    p.stock < 5 ? "bg-red-500/15 text-red-300" : "bg-emerald-500/15 text-emerald-300"
                  }`}>
                    {p.stock}
                  </span>
                </td>
                <td className="p-4">
                  <div className="flex justify-end gap-1">
                    <button onClick={() => setEditing(p)} className="p-2 rounded-lg hover:bg-white/10 transition-colors">
                      <Pencil className="h-3.5 w-3.5" />
                    </button>
                    <button
                      onClick={() => { if (confirm(`Delete "${p.name}"?`)) deleteProduct(p.id); }}
                      className="p-2 rounded-lg hover:bg-destructive/15 hover:text-destructive transition-colors"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {!productsLoading && filtered.length === 0 && (
          <div className="p-12 text-center text-muted-foreground">
            <Package className="h-8 w-8 mx-auto mb-2 opacity-40" />
            <p className="text-sm">No products found</p>
          </div>
        )}
      </div>

      {/* Mobile cards */}
      <div className="md:hidden space-y-2">
        {filtered.map((p) => (
          <div key={p.id} className="flex gap-3 p-3 rounded-xl border border-white/10 bg-[oklch(0.09_0_0)]/80">
            <div className="relative h-16 w-16 rounded-lg overflow-hidden bg-white/5 shrink-0">
              {p.img && <Image src={p.img} alt={p.name} fill className="object-cover" />}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{p.name}</p>
              <p className="text-[11px] text-muted-foreground">{p.sku} · {p.category}</p>
              <div className="flex items-center justify-between mt-1">
                <span className="text-sm">{fmtPKR(p.price)}</span>
                <span className={`text-[10px] px-2 py-0.5 rounded-full ${
                  p.stock < 5 ? "bg-red-500/15 text-red-300" : "bg-emerald-500/15 text-emerald-300"
                }`}>
                  {p.stock} in stock
                </span>
              </div>
            </div>
            <div className="flex flex-col gap-1 shrink-0">
              <button onClick={() => setEditing(p)} className="p-2 rounded-lg bg-white/5 hover:bg-white/10"><Pencil className="h-3.5 w-3.5" /></button>
              <button
                onClick={() => { if (confirm("Delete?")) deleteProduct(p.id); }}
                className="p-2 rounded-lg bg-white/5 hover:bg-destructive/15 hover:text-destructive"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Drawer */}
      {(editing || creating) && (
        <ProductDrawer
          product={editing}
          onClose={() => { setEditing(null); setCreating(false); }}
          onSave={async (data) => {
            if (editing) await updateProduct(editing.id, data);
            else await createProduct(data);
            setEditing(null); setCreating(false);
          }}
        />
      )}
    </div>
  );
}
