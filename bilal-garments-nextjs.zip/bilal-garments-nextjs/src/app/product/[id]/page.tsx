import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getProduct } from "@/lib/products";
import { ProductClient } from "./ProductClient";

type Props = { params: Promise<{ id: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { id } = await params;
  const product = getProduct(id);
  if (!product) return { title: "Product Not Found — BILAL GARMENTS" };
  return {
    title: `${product.name} — BILAL GARMENTS`,
    description: product.description,
    openGraph: {
      title: `${product.name} — BILAL GARMENTS`,
      description: product.description,
      images: [{ url: product.img }],
    },
  };
}

export default async function ProductPage({ params }: Props) {
  const { id } = await params;
  const product = getProduct(id);
  if (!product) notFound();

  return <ProductClient product={product} />;
}
