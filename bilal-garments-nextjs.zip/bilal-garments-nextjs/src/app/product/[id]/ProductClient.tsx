"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { Heart, Minus, Plus, ShoppingBag, Truck, ShieldCheck, RotateCcw, ChevronRight } from "lucide-react";
import { useLenis } from "@/hooks/useLenis";
import { useGsapReveal } from "@/hooks/useGsapReveal";
import { LuxuryHeader } from "@/components/layout/LuxuryHeader";
import { LuxuryFooter } from "@/components/layout/LuxuryFooter";
import { PRODUCTS, fmtPKR, type Product } from "@/lib/products";
import { useStore } from "@/lib/store";

const SIZES = ["S", "M", "L", "XL", "XXL"] as const;

export function ProductClient({ product }: { product: Product }) {
  useLenis();
  const ref = useGsapReveal<HTMLDivElement>();
  const { addToCart, toggleWishlist, isWished } = useStore();
  const router = useRouter();

  const [size, setSize] = useState<(typeof SIZES)[number]>("M");
  const [qty, setQty] = useState(1);

  const related = useMemo(
    () => PRODUCTS.filter((p) => p.id !== product.id && p.category === product.category).slice(0, 3),
    [product.id, product.category],
  );

  const onAdd = () =>
    addToCart({ id: product.id, name: `${product.name} · ${size}`, price: product.price, img: product.img }, qty);
  const onBuyNow = () => { onAdd(); router.push("/cart"); };

  return (
    <div ref={ref} className="relative z-10 text-foreground min-h-screen">
      <LuxuryHeader />
      <main className="pt-32 sm:pt-40 pb-28">
        {/* Breadcrumb */}
        <nav className="px-5 sm:px-8 mb-8" aria-label="Breadcrumb">
          <ol className="mx-auto max-w-7xl flex items-center gap-2 text-xs uppercase tracking-[0.2em] text-foreground/50">
            <li><Link href="/" className="hover:text-foreground transition-colors">Home</Link></li>
            <ChevronRight className="size-3" />
            <li><Link href="/shop" className="hover:text-foreground transition-colors">Shop</Link></li>
            <ChevronRight className="size-3" />
            <li className="text-foreground/80">{product.category}</li>
          </ol>
        </nav>

        <section className="px-5 sm:px-8">
          <div className="mx-auto max-w-7xl grid lg:grid-cols-2 gap-10 lg:gap-16">
            {/* Gallery */}
            <div className="space-y-4" data-reveal>
              <div className="relative aspect-[3/4] rounded-[2rem] overflow-hidden bg-card shadow-luxury group">
                <Image
                  src={product.img}
                  alt={product.name}
                  fill
                  priority
                  className="object-cover transition-transform duration-[1400ms] ease-cinematic group-hover:scale-[1.04]"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background/30 via-transparent to-transparent" />
                {product.tag && (
                  <span className="absolute top-5 left-5 px-3 py-1 rounded-full text-[10px] tracking-[0.2em] uppercase glass">
                    <span className={product.tag === "New" || product.tag === "Limited" ? "text-primary" : ""}>
                      {product.tag}
                    </span>
                  </span>
                )}
              </div>
              <div className="grid grid-cols-3 gap-3">
                {[product.img, product.img, product.img].map((src, i) => (
                  <div key={i} className="relative aspect-square rounded-2xl overflow-hidden bg-card opacity-80 hover:opacity-100 transition-opacity cursor-pointer">
                    <Image src={src} alt="" fill className="object-cover" />
                  </div>
                ))}
              </div>
            </div>

            {/* Details */}
            <div className="lg:pt-6">
              <div className="text-xs tracking-[0.3em] uppercase text-primary mb-4" data-reveal>
                · {product.category} · BILAL
              </div>
              <h1 className="font-display text-5xl sm:text-6xl lg:text-7xl leading-[0.95] mb-6" data-reveal>
                {product.name}
              </h1>
              <div className="flex items-baseline gap-4 mb-8" data-reveal>
                <span className="text-2xl sm:text-3xl text-foreground">{fmtPKR(product.price)}</span>
                <span className="text-xs uppercase tracking-[0.2em] text-foreground/50">Inclusive of all taxes</span>
              </div>
              <p className="text-base sm:text-lg text-foreground/70 leading-relaxed mb-10" data-reveal>
                {product.description}
              </p>

              {/* Size */}
              <div className="mb-8" data-reveal>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs uppercase tracking-[0.2em] text-foreground/60">Size</span>
                  <button className="text-xs uppercase tracking-[0.2em] text-foreground/50 hover:text-primary transition-colors">Size guide</button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {SIZES.map((s) => (
                    <button
                      key={s}
                      onClick={() => setSize(s)}
                      className={`min-w-14 px-4 py-3 rounded-full text-sm transition-all ${
                        size === s
                          ? "bg-foreground text-background"
                          : "glass text-foreground/80 hover:text-foreground hover:scale-105"
                      }`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>

              {/* Qty + Actions */}
              <div className="flex flex-col sm:flex-row items-stretch gap-3 mb-6" data-reveal>
                <div className="flex items-center justify-between glass rounded-full px-2 py-2 sm:w-40">
                  <button
                    aria-label="Decrease quantity"
                    onClick={() => setQty((q) => Math.max(1, q - 1))}
                    className="size-10 grid place-items-center rounded-full hover:bg-glass transition-colors"
                  >
                    <Minus className="size-4" />
                  </button>
                  <span className="text-sm tabular-nums w-8 text-center">{qty}</span>
                  <button
                    aria-label="Increase quantity"
                    onClick={() => setQty((q) => q + 1)}
                    className="size-10 grid place-items-center rounded-full hover:bg-glass transition-colors"
                  >
                    <Plus className="size-4" />
                  </button>
                </div>
                <button
                  onClick={onAdd}
                  className="flex-1 inline-flex items-center justify-center gap-2 px-6 py-4 rounded-full glass text-sm font-semibold tracking-[0.2em] uppercase hover:bg-glass transition-all"
                >
                  <ShoppingBag className="size-4" /> Add to Bag
                </button>
                <button
                  onClick={onBuyNow}
                  className="flex-1 inline-flex items-center justify-center gap-2 px-6 py-4 rounded-full bg-primary text-primary-foreground text-sm font-semibold tracking-[0.2em] uppercase hover:opacity-90 transition-all shadow-luxury"
                >
                  Buy Now
                </button>
              </div>

              <button
                onClick={() => toggleWishlist(product.id, product.name)}
                className="inline-flex items-center gap-2 text-sm text-foreground/70 hover:text-foreground transition-colors mb-10"
              >
                <Heart className={`size-4 ${isWished(product.id) ? "fill-primary text-primary" : ""}`} />
                {isWished(product.id) ? "Saved to wishlist" : "Save to wishlist"}
              </button>

              {/* Trust strip */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3" data-reveal>
                {[
                  { icon: Truck, t: "Free over 25k", s: "Pakistan-wide delivery" },
                  { icon: RotateCcw, t: "7-day returns", s: "Easy exchange" },
                  { icon: ShieldCheck, t: "Authentic", s: "Hand-tailored in Lahore" },
                ].map(({ icon: Icon, t, s }) => (
                  <div key={t} className="glass rounded-2xl p-4 flex items-start gap-3">
                    <Icon className="size-5 text-primary mt-0.5" />
                    <div>
                      <div className="text-sm font-medium">{t}</div>
                      <div className="text-xs text-foreground/60">{s}</div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Details accordion */}
              <div className="mt-10 border-t border-border/50 divide-y divide-border/50">
                {[
                  { t: "Fabric & Care", c: "Premium cotton-silk blend. Dry clean preferred. Iron on reverse." },
                  { t: "Shipping", c: "Dispatched within 48 hours. 3–5 business days nationwide." },
                  { t: "Returns", c: "7-day exchange window for unused items in original packaging." },
                ].map((row) => (
                  <details key={row.t} className="group py-4">
                    <summary className="flex items-center justify-between cursor-pointer list-none">
                      <span className="text-sm uppercase tracking-[0.2em] text-foreground/80">{row.t}</span>
                      <Plus className="size-4 transition-transform group-open:rotate-45" />
                    </summary>
                    <p className="mt-3 text-sm text-foreground/70 leading-relaxed">{row.c}</p>
                  </details>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Related */}
        {related.length > 0 && (
          <section className="px-5 sm:px-8 mt-28">
            <div className="mx-auto max-w-7xl">
              <div className="flex items-end justify-between mb-10">
                <div>
                  <div className="text-xs tracking-[0.3em] uppercase text-primary mb-3" data-reveal>· You may also like</div>
                  <h2 className="font-display text-4xl sm:text-5xl" data-reveal>The Edit Continues.</h2>
                </div>
                <Link href="/shop" className="text-sm text-foreground/70 hover:text-foreground underline underline-offset-8 decoration-primary">
                  Shop all →
                </Link>
              </div>
              <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 lg:gap-8">
                {related.map((p) => (
                  <Link key={p.id} href={`/product/${p.id}`} className="group block" data-reveal>
                    <div className="relative aspect-[3/4] rounded-3xl overflow-hidden bg-card shadow-float">
                      <Image
                        src={p.img}
                        alt={p.name}
                        fill
                        loading="lazy"
                        className="object-cover transition-transform duration-[1200ms] ease-cinematic group-hover:scale-105"
                      />
                    </div>
                    <div className="mt-4 flex items-start justify-between gap-3 px-1">
                      <h3 className="text-sm sm:text-base font-medium">{p.name}</h3>
                      <span className="text-sm sm:text-base text-foreground/80 whitespace-nowrap">{fmtPKR(p.price)}</span>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </section>
        )}
      </main>
      <LuxuryFooter />
    </div>
  );
}
