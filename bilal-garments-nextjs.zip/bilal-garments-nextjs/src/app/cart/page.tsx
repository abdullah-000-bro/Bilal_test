import type { Metadata } from "next";
import { CartClient } from "./CartClient";

export const metadata: Metadata = {
  title: "Your Bag — BILAL GARMENTS",
  description: "Review your selection and complete checkout. Cash on Delivery and Bank Transfer supported.",
};

export default function CartPage() {
  return <CartClient />;
}
