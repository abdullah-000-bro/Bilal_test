"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { Minus, Plus, X, ShoppingBag, ArrowLeft, Check } from "lucide-react";
import { useLenis } from "@/hooks/useLenis";
import { useGsapReveal } from "@/hooks/useGsapReveal";
import { LuxuryHeader } from "@/components/layout/LuxuryHeader";
import { LuxuryFooter } from "@/components/layout/LuxuryFooter";
import { useStore } from "@/lib/store";
import { fmtPKR } from "@/lib/products";
import { publicApi, APIError } from "@/lib/api";
import { toast } from "sonner";

const SHIPPING_FLAT      = 350;
const FREE_SHIPPING_OVER = 25000;

export function CartClient() {
  useLenis();
  const ref = useGsapReveal<HTMLDivElement>();
  const { cart, cartCount, cartTotal, incQty, decQty, removeFromCart, clearCart } = useStore();
  const [step, setStep] = useState<"bag" | "checkout" | "done">("bag");
  const [orderNo, setOrderNo] = useState("");

  const shipping = cartTotal === 0 ? 0 : cartTotal >= FREE_SHIPPING_OVER ? 0 : SHIPPING_FLAT;
  const grand    = cartTotal + shipping;

  return (
    <div ref={ref} className="relative z-10 text-foreground min-h-screen">
      <LuxuryHeader />
      <main className="pt-32 sm:pt-40 pb-28 px-5 sm:px-8">
        <div className="mx-auto max-w-6xl">
          <Link
            href="/shop"
            className="inline-flex items-center gap-2 text-sm text-foreground/60 hover:text-foreground transition-colors mb-8"
          >
            <ArrowLeft className="size-4" /> Continue shopping
          </Link>

          <div className="flex items-end justify-between flex-wrap gap-4 mb-12">
            <div>
              <div className="text-xs tracking-[0.3em] uppercase text-primary mb-3" data-reveal>
                · {step === "done" ? "Order placed" : step === "checkout" ? "Checkout" : "Your Bag"}
              </div>
              <h1 className="font-display text-5xl sm:text-7xl leading-[0.95]" data-reveal>
                {step === "done" ? "Thank you." : step === "checkout" ? "Almost yours." : "Your Selection."}
              </h1>
            </div>
            {step === "bag" && cartCount > 0 && (
              <button
                onClick={clearCart}
                className="text-xs uppercase tracking-[0.2em] text-foreground/50 hover:text-primary transition-colors"
              >
                Clear all
              </button>
            )}
          </div>

          {step === "done" ? (
            <OrderConfirmed
              orderNo={orderNo}
              onReset={() => { clearCart(); setStep("bag"); setOrderNo(""); }}
            />
          ) : cart.length === 0 ? (
            <EmptyState />
          ) : (
            <div className="grid lg:grid-cols-[1fr_400px] gap-8 lg:gap-12 items-start">
              {/* Items / checkout form */}
              <div className="space-y-4">
                {step === "bag"
                  ? cart.map((item) => (
                      <div
                        key={item.id}
                        className="group glass rounded-3xl p-4 sm:p-5 flex gap-4 sm:gap-6 items-center shadow-float"
                      >
                        <div className="relative size-24 sm:size-28 rounded-2xl overflow-hidden shrink-0 bg-card">
                          <Image
                            src={item.img}
                            alt={item.name}
                            fill
                            className="object-cover transition-transform duration-700 group-hover:scale-105"
                          />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className="text-base sm:text-lg font-medium leading-snug truncate">{item.name}</h3>
                          {item.size && (
                            <p className="text-xs text-foreground/50 mt-0.5">Size: {item.size}</p>
                          )}
                          <p className="text-xs text-foreground/50 mt-1 uppercase tracking-wider">
                            {fmtPKR(item.price)}
                          </p>
                          <div className="mt-3 inline-flex items-center gap-1 rounded-full bg-surface-elevated/60 p-1">
                            <button
                              aria-label="Decrease"
                              onClick={() => decQty(item.id)}
                              className="size-8 grid place-items-center rounded-full hover:bg-glass transition-colors"
                            >
                              <Minus className="size-3.5" />
                            </button>
                            <span className="w-8 text-center text-sm font-medium">{item.qty}</span>
                            <button
                              aria-label="Increase"
                              onClick={() => incQty(item.id)}
                              className="size-8 grid place-items-center rounded-full hover:bg-glass transition-colors"
                            >
                              <Plus className="size-3.5" />
                            </button>
                          </div>
                        </div>
                        <div className="flex flex-col items-end gap-3 shrink-0">
                          <span className="text-sm sm:text-base whitespace-nowrap">
                            {fmtPKR(item.price * item.qty)}
                          </span>
                          <button
                            aria-label="Remove"
                            onClick={() => {
                              removeFromCart(item.id);
                              toast("Removed from bag", { description: item.name });
                            }}
                            className="size-8 grid place-items-center rounded-full hover:bg-primary/15 hover:text-primary transition-colors text-foreground/50"
                          >
                            <X className="size-4" />
                          </button>
                        </div>
                      </div>
                    ))
                  : (
                    <CheckoutForm
                      cart={cart}
                      grand={grand}
                      shipping={shipping}
                      onPlaced={(no) => { setOrderNo(no); setStep("done"); }}
                    />
                  )}
              </div>

              {/* Order summary */}
              <aside className="lg:sticky lg:top-32">
                <div className="glass rounded-3xl p-6 sm:p-8 shadow-luxury">
                  <h2 className="font-display text-2xl mb-6">Order Summary</h2>
                  <Row label={`Subtotal (${cartCount} item${cartCount !== 1 ? "s" : ""})`} value={fmtPKR(cartTotal)} />
                  <Row label="Shipping" value={shipping === 0 ? "Free" : fmtPKR(shipping)} />
                  {cartTotal > 0 && cartTotal < FREE_SHIPPING_OVER && (
                    <p className="text-xs text-foreground/50 -mt-2 mb-4">
                      Add {fmtPKR(FREE_SHIPPING_OVER - cartTotal)} more for free shipping.
                    </p>
                  )}
                  <div className="h-px bg-border/50 my-4" />
                  <div className="flex items-baseline justify-between">
                    <span className="text-sm text-foreground/70">Total</span>
                    <span className="font-display text-3xl">{fmtPKR(grand)}</span>
                  </div>
                  {step === "bag" ? (
                    <button
                      onClick={() => setStep("checkout")}
                      className="mt-8 w-full py-4 rounded-full bg-primary text-primary-foreground font-medium hover:opacity-90 transition-all"
                    >
                      Proceed to Checkout
                    </button>
                  ) : (
                    <button
                      type="submit"
                      form="checkout-form"
                      className="mt-8 w-full py-4 rounded-full bg-primary text-primary-foreground font-medium hover:opacity-90 transition-all"
                    >
                      Place Order
                    </button>
                  )}
                  <p className="mt-4 text-[11px] text-center text-foreground/50 tracking-wider uppercase">
                    Secure checkout · COD · Bank Transfer
                  </p>
                </div>
              </aside>
            </div>
          )}
        </div>
      </main>
      <LuxuryFooter />
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between py-2">
      <span className="text-sm text-foreground/70">{label}</span>
      <span className="text-sm">{value}</span>
    </div>
  );
}

function EmptyState() {
  return (
    <div className="glass rounded-3xl p-12 sm:p-20 text-center shadow-float">
      <div className="mx-auto size-16 grid place-items-center rounded-full bg-surface-elevated/60 mb-6">
        <ShoppingBag className="size-7 text-foreground/60" />
      </div>
      <h2 className="font-display text-3xl sm:text-4xl mb-3">Your bag is empty.</h2>
      <p className="text-foreground/60 mb-8 max-w-md mx-auto">
        Discover hand-tailored pieces from our latest cinematic drop.
      </p>
      <Link
        href="/shop"
        className="inline-flex items-center gap-2 px-8 py-4 rounded-full bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition-all"
      >
        Shop the Collection →
      </Link>
    </div>
  );
}

function OrderConfirmed({ orderNo, onReset }: { orderNo: string; onReset: () => void }) {
  const router = useRouter();
  return (
    <div className="glass rounded-3xl p-12 sm:p-20 text-center shadow-luxury">
      <div className="mx-auto size-20 grid place-items-center rounded-full bg-primary/15 text-primary mb-6">
        <Check className="size-9" strokeWidth={2.5} />
      </div>
      <h2 className="font-display text-4xl sm:text-5xl mb-4">Order placed.</h2>
      <p className="text-foreground/60 max-w-md mx-auto mb-2">
        We&apos;ve received your order. Our team will confirm via WhatsApp within 24 hours.
      </p>
      {orderNo && (
        <p className="text-xs text-foreground/40 uppercase tracking-[0.2em] mb-8">
          Reference: {orderNo}
        </p>
      )}
      <div className="flex flex-wrap justify-center gap-3">
        <button
          onClick={() => { onReset(); router.push("/shop"); }}
          className="px-8 py-4 rounded-full bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition-all"
        >
          Continue shopping
        </button>
        <button
          onClick={() => { onReset(); router.push("/"); }}
          className="px-8 py-4 rounded-full glass text-sm hover:bg-glass transition-all"
        >
          Back to home
        </button>
      </div>
    </div>
  );
}

type CartItemType = { id: number; name: string; price: number; img: string; qty: number; size?: string };

function CheckoutForm({
  cart, grand, shipping, onPlaced,
}: {
  cart: CartItemType[];
  grand: number;
  shipping: number;
  onPlaced: (orderNo: string) => void;
}) {
  const [pay, setPay]         = useState<"COD" | "Bank">("COD");
  const [submitting, setSubmitting] = useState(false);

  const inputCls =
    "w-full bg-surface-elevated/40 border border-border/50 rounded-2xl px-4 py-3 text-sm text-foreground placeholder:text-foreground/30 focus:outline-none focus:border-primary/60 transition-all";

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const data  = new FormData(e.currentTarget);
    const name    = String(data.get("name")    ?? "").trim();
    const phone   = String(data.get("phone")   ?? "").trim();
    const email   = String(data.get("email")   ?? "").trim();
    const city    = String(data.get("city")    ?? "").trim();
    const address = String(data.get("address") ?? "").trim();
    const notes   = String(data.get("notes")   ?? "").trim();

    if (!name || !phone || !city || !address) {
      toast.error("Please complete all required fields");
      return;
    }

    setSubmitting(true);
    try {
      const res = await publicApi.placeOrder({
        name, phone, email, city, address, notes,
        payment: pay,
        items: cart.map((i) => ({
          product_id: i.id,
          qty: i.qty,
          size: i.size ?? "",
        })),
      });
      onPlaced(res.data.order_no);
    } catch (err) {
      if (err instanceof APIError) {
        toast.error(err.message);
      } else {
        toast.error("Could not place order. Please try again.");
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form id="checkout-form" onSubmit={onSubmit} className="space-y-8">
      {/* Delivery */}
      <section className="glass rounded-3xl p-6 sm:p-8 shadow-float">
        <h2 className="font-display text-2xl mb-6">Delivery Details</h2>
        <div className="grid sm:grid-cols-2 gap-4">
          {[
            { name: "name",  label: "Full Name",          placeholder: "Bilal Ahmed",          type: "text",  req: true },
            { name: "phone", label: "Phone",               placeholder: "+92 300 0000000",      type: "tel",   req: true },
            { name: "email", label: "Email (optional)",    placeholder: "you@email.com",        type: "email", req: false },
            { name: "city",  label: "City",                placeholder: "Lahore",               type: "text",  req: true },
          ].map((f) => (
            <label key={f.name} className="block">
              <span className="text-xs uppercase tracking-[0.18em] text-foreground/60 mb-2 block">
                {f.label}{f.req && <span className="text-primary"> *</span>}
              </span>
              <input name={f.name} type={f.type} placeholder={f.placeholder} className={inputCls} />
            </label>
          ))}
          <label className="block sm:col-span-2">
            <span className="text-xs uppercase tracking-[0.18em] text-foreground/60 mb-2 block">
              Address <span className="text-primary">*</span>
            </span>
            <input name="address" placeholder="House #, Street, Area" className={inputCls} />
          </label>
          <label className="block sm:col-span-2">
            <span className="text-xs uppercase tracking-[0.18em] text-foreground/60 mb-2 block">
              Order Notes (optional)
            </span>
            <textarea name="notes" placeholder="Any preferences for tailoring or delivery…" rows={3} className={inputCls + " resize-none"} />
          </label>
        </div>
      </section>

      {/* Payment */}
      <section className="glass rounded-3xl p-6 sm:p-8 shadow-float">
        <h2 className="font-display text-2xl mb-6">Payment Method</h2>
        <div className="grid sm:grid-cols-2 gap-3">
          {([
            { val: "COD",  title: "Cash on Delivery",  desc: "Pay in cash when your order arrives." },
            { val: "Bank", title: "Bank Transfer",     desc: "Get account details after placing order." },
          ] as const).map((opt) => (
            <button
              key={opt.val}
              type="button"
              onClick={() => setPay(opt.val)}
              className={`text-left rounded-2xl p-4 sm:p-5 border transition-all ${
                pay === opt.val
                  ? "border-primary bg-primary/5 shadow-glow"
                  : "border-border/50 bg-surface-elevated/30 hover:border-foreground/30"
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-medium">{opt.title}</span>
                <span className={`size-4 rounded-full border-2 transition-all ${pay === opt.val ? "border-primary bg-primary" : "border-foreground/40"}`} />
              </div>
              <p className="text-xs text-foreground/55 mt-1.5">{opt.desc}</p>
            </button>
          ))}
        </div>
        {pay === "Bank" && (
          <p className="mt-4 text-xs text-foreground/60 leading-relaxed">
            Account details will be shared via WhatsApp once your order is confirmed.
          </p>
        )}
      </section>

      {submitting && (
        <p className="text-center text-sm text-foreground/60 flex items-center justify-center gap-2">
          <span className="h-4 w-4 rounded-full border-2 border-foreground/30 border-t-foreground animate-spin" />
          Placing your order…
        </p>
      )}
    </form>
  );
}
