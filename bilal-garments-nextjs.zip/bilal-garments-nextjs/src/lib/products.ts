export type Category = "Men" | "Boys" | "Kids";

export type Product = {
  id: string;
  name: string;
  price: number;
  img: string;
  tag?: "New" | "Trending" | "Limited" | null;
  category: Category;
  description: string;
};

export const PRODUCTS: Product[] = [
  {
    id: "p1",
    name: "Onyx Mandarin Kurta",
    price: 14500,
    img: "/assets/p1.jpg",
    tag: "New",
    category: "Men",
    description:
      "Mandarin collar in onyx black cotton-silk. Hand-finished placket, mother-of-pearl buttons.",
  },
  {
    id: "p2",
    name: "Ivory Heritage Kameez",
    price: 18900,
    img: "/assets/p2.jpg",
    tag: null,
    category: "Men",
    description:
      "Ivory heritage kameez with subtle textured weave. Tailored for an elegant, confident silhouette.",
  },
  {
    id: "p3",
    name: "Noir Bomber Jacket",
    price: 22500,
    img: "/assets/p3.jpg",
    tag: "Trending",
    category: "Men",
    description:
      "Cropped noir bomber with ribbed cuffs and concealed zip — engineered for cinematic streetwear.",
  },
  {
    id: "p4",
    name: "Slate Tailored Waistcoat",
    price: 16800,
    img: "/assets/p4.jpg",
    tag: null,
    category: "Men",
    description:
      "Slate-grey wool-blend waistcoat. Sculpted lapels, satin lining, hand-finished welt pockets.",
  },
  {
    id: "p5",
    name: "Shadow Hoodie",
    price: 9500,
    img: "/assets/p5.jpg",
    tag: "Limited",
    category: "Boys",
    description:
      "Mid-weight shadow hoodie in brushed cotton. Drop-shoulder cut with embroidered crest.",
  },
  {
    id: "p6",
    name: "Royal Cream Sherwani",
    price: 48000,
    img: "/assets/p6.jpg",
    tag: null,
    category: "Men",
    description:
      "Royal cream sherwani in raw silk. Hand-embroidered placket, mirror-finish buttons.",
  },
  {
    id: "p7",
    name: "Charcoal Linen Shalwar",
    price: 7800,
    img: "/assets/p2.jpg",
    tag: null,
    category: "Men",
    description:
      "Featherweight charcoal linen shalwar — fluid drape, hidden drawstring, tonal stitch.",
  },
  {
    id: "p8",
    name: "Midnight Prince Coat",
    price: 38500,
    img: "/assets/p4.jpg",
    tag: "New",
    category: "Men",
    description:
      "Floor-grazing prince coat in midnight wool. Notch lapel, structured shoulder, grosgrain trim.",
  },
  {
    id: "p9",
    name: "Junior Noir Kurta",
    price: 6900,
    img: "/assets/p1.jpg",
    tag: null,
    category: "Boys",
    description:
      "Mini-me noir kurta cut for junior gentlemen. Soft cotton, easy fit, statement collar.",
  },
  {
    id: "p10",
    name: "Cub Ivory Set",
    price: 5400,
    img: "/assets/p2.jpg",
    tag: "Trending",
    category: "Kids",
    description: "Two-piece ivory set for the youngest royals. Breathable cotton, gentle on skin.",
  },
  {
    id: "p11",
    name: "Pocket Cream Sherwani",
    price: 12500,
    img: "/assets/p6.jpg",
    tag: "Limited",
    category: "Boys",
    description: "Pint-sized sherwani in cream raw silk. Show-stopping wedding-ready finish.",
  },
  {
    id: "p12",
    name: "Tiny Shadow Hoodie",
    price: 4900,
    img: "/assets/p5.jpg",
    tag: null,
    category: "Kids",
    description: "Cosy shadow hoodie scaled for kids. Soft brushed interior, kangaroo pocket.",
  },
];

export const fmtPKR = (n: number) => `PKR ${n.toLocaleString("en-PK")}`;

export const getProduct = (id: string) => PRODUCTS.find((p) => p.id === id);
