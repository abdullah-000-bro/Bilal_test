// ============================================================
//  BILAL GARMENTS — API Client (Next.js ↔ PHP Backend)
// ============================================================

const API_BASE = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost/bilal-garments-backend';

// ── Token Management ─────────────────────────────────────────
export const getToken = (): string | null =>
  typeof window !== 'undefined' ? localStorage.getItem('bg_admin_token') : null;

export const setToken = (t: string) => localStorage.setItem('bg_admin_token', t);
export const clearToken = () => localStorage.removeItem('bg_admin_token');

// ── Core Fetch ───────────────────────────────────────────────
async function apiFetch<T>(
  path: string,
  options: RequestInit = {},
  auth = false,
): Promise<T> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string>),
  };

  if (auth) {
    const token = getToken();
    if (token) headers['Authorization'] = `Bearer ${token}`;
  }

  const res = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers,
  });

  const json = await res.json();

  if (!res.ok) {
    throw new APIError(json.message ?? 'Request failed', res.status, json.errors);
  }

  return json as T;
}

export class APIError extends Error {
  constructor(
    message: string,
    public status: number,
    public errors?: Record<string, string>,
  ) {
    super(message);
    this.name = 'APIError';
  }
}

// ── Types ────────────────────────────────────────────────────
export type ApiProduct = {
  id: number;
  sku: string;
  name: string;
  slug: string;
  description: string;
  price: number;
  sale_price: number | null;
  category: string;
  category_slug: string;
  tag: 'New' | 'Trending' | 'Limited' | '';
  img: string;
  stock: number;
  related?: ApiProduct[];
};

export type ApiOrder = {
  id: number;
  order_no: string;
  customer_name: string;
  customer_email: string;
  customer_phone: string;
  city: string;
  address: string;
  notes?: string;
  subtotal: number;
  shipping: number;
  tax: number;
  total: number;
  status: 'Pending' | 'Processing' | 'Shipped' | 'Delivered' | 'Cancelled';
  payment: 'COD' | 'Card' | 'Bank';
  item_count?: number;
  items?: ApiOrderItem[];
  created_at: string;
  updated_at: string;
};

export type ApiOrderItem = {
  id: number;
  product_id: number;
  name: string;
  sku: string;
  size: string;
  price: number;
  qty: number;
  total: number;
};

export type ApiCustomer = {
  id: number;
  name: string;
  email: string;
  phone: string;
  city: string;
  total_orders: number;
  total_spent: number;
  last_order_at: string;
  created_at: string;
};

export type PaginatedResponse<T> = {
  success: boolean;
  data: T[];
  pagination: {
    total: number;
    page: number;
    page_size: number;
    total_pages: number;
  };
};

export type DashboardData = {
  stats: {
    revenue: number;
    total_orders: number;
    pending_orders: number;
    revenue_today: number;
    orders_today: number;
    customers: number;
    products: number;
    low_stock: number;
  };
  chart: { date: string; label: string; revenue: number; orders: number }[];
  recent: ApiOrder[];
};

export type AnalyticsData = {
  by_category: { name: string; revenue: number }[];
  by_status: { name: string; value: number }[];
  monthly: { name: string; revenue: number }[];
  top_products: { name: string; qty: number; revenue: number }[];
  by_city: { name: string; orders: number; revenue: number }[];
};

export type ApiSettings = {
  store_name: string;
  currency: string;
  email: string;
  phone: string;
  address: string;
  free_shipping_over: number;
  shipping_flat: number;
  tax_pct: number;
  maintenance: boolean;
};

// ── Public API ───────────────────────────────────────────────
export const publicApi = {
  getProducts: (params: Record<string, string | number> = {}) => {
    const qs = new URLSearchParams(params as Record<string, string>).toString();
    return apiFetch<PaginatedResponse<ApiProduct>>(`/api/products${qs ? '?' + qs : ''}`);
  },

  getProduct: (id: string | number) =>
    apiFetch<{ success: boolean; data: ApiProduct }>(`/api/products/${id}`),

  placeOrder: (body: {
    name: string;
    phone: string;
    email: string;
    city: string;
    address: string;
    notes?: string;
    payment: string;
    items: { product_id: number; qty: number; size: string }[];
  }) =>
    apiFetch<{ success: boolean; data: { order_no: string; total: number } }>(
      '/api/orders',
      { method: 'POST', body: JSON.stringify(body) },
    ),
};

// ── Admin API ────────────────────────────────────────────────
export const adminApi = {
  login: async (username: string, password: string) => {
    const res = await apiFetch<{ success: boolean; data: { token: string; user: object } }>(
      '/api/auth/login',
      { method: 'POST', body: JSON.stringify({ username, password }) },
    );
    if (res.data.token) setToken(res.data.token);
    return res.data;
  },

  logout: () => clearToken(),

  // Dashboard
  getDashboard: () =>
    apiFetch<{ success: boolean; data: DashboardData }>('/api/admin/dashboard', {}, true),

  // Analytics
  getAnalytics: () =>
    apiFetch<{ success: boolean; data: AnalyticsData }>('/api/admin/analytics', {}, true),

  // Products
  getProducts: (params: Record<string, string | number> = {}) => {
    const qs = new URLSearchParams(params as Record<string, string>).toString();
    return apiFetch<PaginatedResponse<ApiProduct>>(`/api/products${qs ? '?' + qs : ''}`);
  },
  createProduct: (data: Partial<ApiProduct>) =>
    apiFetch<{ success: boolean; data: ApiProduct }>(
      '/api/admin/products',
      { method: 'POST', body: JSON.stringify(data) },
      true,
    ),
  updateProduct: (id: number, data: Partial<ApiProduct>) =>
    apiFetch<{ success: boolean; data: ApiProduct }>(
      `/api/admin/products/${id}`,
      { method: 'PUT', body: JSON.stringify(data) },
      true,
    ),
  deleteProduct: (id: number) =>
    apiFetch<{ success: boolean; data: object }>(
      `/api/admin/products/${id}`,
      { method: 'DELETE' },
      true,
    ),

  // Orders
  getOrders: (params: Record<string, string | number> = {}) => {
    const qs = new URLSearchParams(params as Record<string, string>).toString();
    return apiFetch<PaginatedResponse<ApiOrder>>(`/api/admin/orders${qs ? '?' + qs : ''}`, {}, true);
  },
  getOrder: (id: number) =>
    apiFetch<{ success: boolean; data: ApiOrder }>(`/api/admin/orders/${id}`, {}, true),
  updateOrderStatus: (id: number, status: string) =>
    apiFetch<{ success: boolean; data: object }>(
      `/api/admin/orders/${id}/status`,
      { method: 'PATCH', body: JSON.stringify({ status }) },
      true,
    ),
  deleteOrder: (id: number) =>
    apiFetch<{ success: boolean; data: object }>(
      `/api/admin/orders/${id}`,
      { method: 'DELETE' },
      true,
    ),

  // Customers
  getCustomers: (params: Record<string, string | number> = {}) => {
    const qs = new URLSearchParams(params as Record<string, string>).toString();
    return apiFetch<PaginatedResponse<ApiCustomer>>(`/api/admin/customers${qs ? '?' + qs : ''}`, {}, true);
  },

  // Settings
  getSettings: () =>
    apiFetch<{ success: boolean; data: ApiSettings }>('/api/admin/settings', {}, true),
  updateSettings: (data: Partial<ApiSettings>) =>
    apiFetch<{ success: boolean; data: ApiSettings }>(
      '/api/admin/settings',
      { method: 'PUT', body: JSON.stringify(data) },
      true,
    ),

  // Upload
  uploadImage: async (file: File): Promise<string> => {
    const form = new FormData();
    form.append('image', file);
    const token = getToken();
    const res = await fetch(`${API_BASE}/api/admin/upload`, {
      method: 'POST',
      headers: token ? { Authorization: `Bearer ${token}` } : {},
      body: form,
    });
    const json = await res.json();
    if (!res.ok) throw new APIError(json.message, res.status);
    return json.data.url as string;
  },
};
