"use client";

import {
  createContext, useCallback, useContext,
  useEffect, useMemo, useState, type ReactNode,
} from "react";
import { toast } from "sonner";
import {
  adminApi, type ApiOrder, type ApiCustomer,
  type ApiSettings, type DashboardData, type AnalyticsData,
  type ApiProduct, APIError,
} from "@/lib/api";

type AdminCtx = {
  isAuthed: boolean;
  loading: boolean;
  login: (u: string, p: string) => Promise<boolean>;
  logout: () => void;
  products: ApiProduct[];
  productsLoading: boolean;
  fetchProducts: () => Promise<void>;
  createProduct: (data: Partial<ApiProduct>) => Promise<void>;
  updateProduct: (id: number, data: Partial<ApiProduct>) => Promise<void>;
  deleteProduct: (id: number) => Promise<void>;
  orders: ApiOrder[];
  ordersLoading: boolean;
  ordersPagination: { total: number; page: number; total_pages: number } | null;
  fetchOrders: (params?: Record<string, string | number>) => Promise<void>;
  updateOrderStatus: (id: number, status: string) => Promise<void>;
  deleteOrder: (id: number) => Promise<void>;
  customers: ApiCustomer[];
  customersLoading: boolean;
  fetchCustomers: (params?: Record<string, string | number>) => Promise<void>;
  dashboard: DashboardData | null;
  dashboardLoading: boolean;
  fetchDashboard: () => Promise<void>;
  analytics: AnalyticsData | null;
  analyticsLoading: boolean;
  fetchAnalytics: () => Promise<void>;
  settings: ApiSettings | null;
  settingsLoading: boolean;
  fetchSettings: () => Promise<void>;
  saveSettings: (data: Partial<ApiSettings>) => Promise<void>;
};

const C = createContext<AdminCtx | null>(null);

export function AdminProvider({ children }: { children: ReactNode }) {
  const [isAuthed, setIsAuthed] = useState(false);
  const [loading, setLoading]   = useState(true);
  const [products, setProducts] = useState<ApiProduct[]>([]);
  const [productsLoading, setProductsLoading] = useState(false);
  const [orders, setOrders]     = useState<ApiOrder[]>([]);
  const [ordersLoading, setOrdersLoading]     = useState(false);
  const [ordersPagination, setOrdersPagination] = useState<AdminCtx["ordersPagination"]>(null);
  const [customers, setCustomers] = useState<ApiCustomer[]>([]);
  const [customersLoading, setCustomersLoading] = useState(false);
  const [dashboard, setDashboard] = useState<DashboardData | null>(null);
  const [dashboardLoading, setDashboardLoading] = useState(false);
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
  const [analyticsLoading, setAnalyticsLoading] = useState(false);
  const [settings, setSettings]   = useState<ApiSettings | null>(null);
  const [settingsLoading, setSettingsLoading] = useState(false);

  useEffect(() => {
    const token = typeof window !== "undefined" ? localStorage.getItem("bg_admin_token") : null;
    setIsAuthed(!!token);
    setLoading(false);
  }, []);

  const login = useCallback(async (username: string, password: string): Promise<boolean> => {
    try { await adminApi.login(username, password); setIsAuthed(true); return true; }
    catch (err) { if (err instanceof APIError) toast.error(err.message); return false; }
  }, []);

  const logout = useCallback(() => { adminApi.logout(); setIsAuthed(false); }, []);

  const fetchProducts = useCallback(async () => {
    setProductsLoading(true);
    try { const r = await adminApi.getProducts({ per_page: 100 }); setProducts(r.data); }
    catch { toast.error("Failed to load products"); }
    finally { setProductsLoading(false); }
  }, []);

  const createProduct = useCallback(async (data: Partial<ApiProduct>) => {
    const r = await adminApi.createProduct(data);
    setProducts((p) => [r.data, ...p]);
    toast.success("Product created");
  }, []);

  const updateProduct = useCallback(async (id: number, data: Partial<ApiProduct>) => {
    const r = await adminApi.updateProduct(id, data);
    setProducts((p) => p.map((x) => x.id === id ? r.data : x));
    toast.success("Product updated");
  }, []);

  const deleteProduct = useCallback(async (id: number) => {
    await adminApi.deleteProduct(id);
    setProducts((p) => p.filter((x) => x.id !== id));
    toast.success("Product deleted");
  }, []);

  const fetchOrders = useCallback(async (params: Record<string, string | number> = {}) => {
    setOrdersLoading(true);
    try { const r = await adminApi.getOrders({ per_page: 50, ...params }); setOrders(r.data); setOrdersPagination(r.pagination); }
    catch { toast.error("Failed to load orders"); }
    finally { setOrdersLoading(false); }
  }, []);

  const updateOrderStatus = useCallback(async (id: number, status: string) => {
    await adminApi.updateOrderStatus(id, status);
    setOrders((o) => o.map((x) => x.id === id ? { ...x, status: status as ApiOrder["status"] } : x));
    toast.success("Status updated");
  }, []);

  const deleteOrder = useCallback(async (id: number) => {
    await adminApi.deleteOrder(id);
    setOrders((o) => o.filter((x) => x.id !== id));
    toast.success("Order deleted");
  }, []);

  const fetchCustomers = useCallback(async (params: Record<string, string | number> = {}) => {
    setCustomersLoading(true);
    try { const r = await adminApi.getCustomers({ per_page: 100, ...params }); setCustomers(r.data); }
    catch { toast.error("Failed to load customers"); }
    finally { setCustomersLoading(false); }
  }, []);

  const fetchDashboard = useCallback(async () => {
    setDashboardLoading(true);
    try { const r = await adminApi.getDashboard(); setDashboard(r.data); }
    catch { toast.error("Failed to load dashboard"); }
    finally { setDashboardLoading(false); }
  }, []);

  const fetchAnalytics = useCallback(async () => {
    setAnalyticsLoading(true);
    try { const r = await adminApi.getAnalytics(); setAnalytics(r.data); }
    catch { toast.error("Failed to load analytics"); }
    finally { setAnalyticsLoading(false); }
  }, []);

  const fetchSettings = useCallback(async () => {
    setSettingsLoading(true);
    try { const r = await adminApi.getSettings(); setSettings(r.data); }
    catch { toast.error("Failed to load settings"); }
    finally { setSettingsLoading(false); }
  }, []);

  const saveSettings = useCallback(async (data: Partial<ApiSettings>) => {
    const r = await adminApi.updateSettings(data);
    setSettings(r.data);
    toast.success("Settings saved");
  }, []);

  const value = useMemo<AdminCtx>(() => ({
    isAuthed, loading, login, logout,
    products, productsLoading, fetchProducts, createProduct, updateProduct, deleteProduct,
    orders, ordersLoading, ordersPagination, fetchOrders, updateOrderStatus, deleteOrder,
    customers, customersLoading, fetchCustomers,
    dashboard, dashboardLoading, fetchDashboard,
    analytics, analyticsLoading, fetchAnalytics,
    settings, settingsLoading, fetchSettings, saveSettings,
  }), [isAuthed, loading, login, logout, products, productsLoading, fetchProducts, createProduct, updateProduct, deleteProduct, orders, ordersLoading, ordersPagination, fetchOrders, updateOrderStatus, deleteOrder, customers, customersLoading, fetchCustomers, dashboard, dashboardLoading, fetchDashboard, analytics, analyticsLoading, fetchAnalytics, settings, settingsLoading, fetchSettings, saveSettings]);

  return <C.Provider value={value}>{children}</C.Provider>;
}

export function useAdmin() {
  const ctx = useContext(C);
  if (!ctx) throw new Error("useAdmin must be inside AdminProvider");
  return ctx;
}

export type { ApiOrder, ApiCustomer, ApiSettings, ApiProduct };
export type OrderStatus = ApiOrder["status"];
export type AdminProduct = ApiProduct & { stock: number; sku: string };
export const CATEGORIES = ["Men", "Boys", "Kids"] as const;
