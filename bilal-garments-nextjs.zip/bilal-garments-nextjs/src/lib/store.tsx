"use client";

import {
  createContext, useCallback, useContext, useEffect,
  useMemo, useState, type ReactNode,
} from "react";
import { toast } from "sonner";
import { publicApi, type ApiProduct } from "@/lib/api";

export type CartItem = {
  id: number;
  name: string;
  price: number;
  img: string;
  qty: number;
  size?: string;
};

type StoreCtx = {
  cart: CartItem[];
  cartCount: number;
  cartTotal: number;
  wishlist: number[];
  addToCart: (item: Omit<CartItem, "qty">, qty?: number) => void;
  removeFromCart: (id: number) => void;
  incQty: (id: number) => void;
  decQty: (id: number) => void;
  clearCart: () => void;
  toggleWishlist: (id: number, name?: string) => void;
  isWished: (id: number) => boolean;
  products: ApiProduct[];
  loadingProducts: boolean;
  fetchProducts: (params?: Record<string, string | number>) => Promise<void>;
};

const Ctx = createContext<StoreCtx | null>(null);
const CART_KEY = "bilal:cart";
const WISH_KEY = "bilal:wishlist";

export function StoreProvider({ children }: { children: ReactNode }) {
  const [cart, setCart]         = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<number[]>([]);
  const [products, setProducts] = useState<ApiProduct[]>([]);
  const [loadingProducts, setLoadingProducts] = useState(false);

  useEffect(() => {
    try {
      const c = localStorage.getItem(CART_KEY);
      const w = localStorage.getItem(WISH_KEY);
      if (c) setCart(JSON.parse(c));
      if (w) setWishlist(JSON.parse(w));
    } catch {}
  }, []);

  useEffect(() => {
    try { localStorage.setItem(CART_KEY, JSON.stringify(cart)); } catch {}
  }, [cart]);

  useEffect(() => {
    try { localStorage.setItem(WISH_KEY, JSON.stringify(wishlist)); } catch {}
  }, [wishlist]);

  const fetchProducts = useCallback(async (params: Record<string, string | number> = {}) => {
    setLoadingProducts(true);
    try {
      const res = await publicApi.getProducts(params);
      setProducts(res.data);
    } catch (err) {
      console.error("Failed to fetch products:", err);
    } finally {
      setLoadingProducts(false);
    }
  }, []);

  const addToCart = useCallback((item: Omit<CartItem, "qty">, qty = 1) => {
    setCart((prev) => {
      const found = prev.find((p) => p.id === item.id);
      if (found) return prev.map((p) => p.id === item.id ? { ...p, qty: p.qty + qty } : p);
      return [...prev, { ...item, qty }];
    });
    toast.success("Added to bag", { description: item.name });
  }, []);

  const removeFromCart = useCallback((id: number) => setCart((prev) => prev.filter((p) => p.id !== id)), []);
  const incQty         = useCallback((id: number) => setCart((prev) => prev.map((p) => p.id === id ? { ...p, qty: p.qty + 1 } : p)), []);
  const decQty         = useCallback((id: number) => setCart((prev) => prev.flatMap((p) => { if (p.id !== id) return [p]; if (p.qty <= 1) return []; return [{ ...p, qty: p.qty - 1 }]; })), []);
  const clearCart      = useCallback(() => setCart([]), []);

  const toggleWishlist = useCallback((id: number, name?: string) => {
    setWishlist((prev) => {
      if (prev.includes(id)) { toast("Removed from wishlist", { description: name }); return prev.filter((x) => x !== id); }
      toast.success("Saved to wishlist", { description: name });
      return [...prev, id];
    });
  }, []);

  const value = useMemo<StoreCtx>(() => ({
    cart,
    cartCount: cart.reduce((s, i) => s + i.qty, 0),
    cartTotal: cart.reduce((s, i) => s + i.qty * i.price, 0),
    wishlist,
    addToCart, removeFromCart, incQty, decQty, clearCart, toggleWishlist,
    isWished: (id) => wishlist.includes(id),
    products, loadingProducts, fetchProducts,
  }), [cart, wishlist, products, loadingProducts, addToCart, removeFromCart, incQty, decQty, clearCart, toggleWishlist, fetchProducts]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useStore() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useStore must be inside StoreProvider");
  return ctx;
}
