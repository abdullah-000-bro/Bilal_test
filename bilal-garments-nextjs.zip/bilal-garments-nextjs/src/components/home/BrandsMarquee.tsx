const BRANDS = [
  "Khaadi","Sapphire","Gul Ahmed","Alkaram Studio","Nishat Linen",
  "Bonanza Satrangi","Maria B.","HSY","Sana Safinaz","Generation",
  "Outfitters","Cross Stitch","Limelight","J.","Asim Jofa",
  "Élan","Zellbury","Ideas by Gul Ahmed",
];

export function BrandsMarquee() {
  const loop = [...BRANDS, ...BRANDS];

  return (
    <section
      aria-label="Featured Pakistani fashion houses"
      className="relative py-14 sm:py-16 border-y border-border/60 bg-surface/30 overflow-hidden"
    >
      <div className="mx-auto max-w-7xl px-5 sm:px-8 mb-8 flex flex-col items-center text-center">
        <div className="text-xs tracking-[0.3em] uppercase text-primary mb-3">
          · In Good Company
        </div>
        <h3 className="font-display text-2xl sm:text-3xl text-foreground/80">
          Alongside Pakistan&apos;s finest fashion houses
        </h3>
      </div>

      <div className="relative mask-fade-x">
        <div className="flex w-max animate-marquee gap-12 sm:gap-16 will-change-transform">
          {loop.map((name, i) => (
            <span
              key={`${name}-${i}`}
              className="font-display text-3xl sm:text-5xl tracking-[0.08em] text-foreground/55 hover:text-primary transition-colors duration-500 whitespace-nowrap flex items-center gap-12 sm:gap-16"
            >
              {name}
              <span aria-hidden className="size-1.5 rounded-full bg-primary/60 shrink-0" />
            </span>
          ))}
        </div>

        <div className="mt-6 flex w-max animate-marquee-reverse gap-10 sm:gap-14 will-change-transform opacity-60">
          {loop.map((name, i) => (
            <span
              key={`r-${name}-${i}`}
              className="font-sans text-xs sm:text-sm tracking-[0.35em] uppercase text-foreground/50 whitespace-nowrap flex items-center gap-10 sm:gap-14"
            >
              {name}
              <span aria-hidden className="h-px w-10 bg-border" />
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
