"use client";

import { useLenis } from "@/hooks/useLenis";
import { useGsapReveal } from "@/hooks/useGsapReveal";

export function HomeClient({ children }: { children: React.ReactNode }) {
  useLenis();
  const ref = useGsapReveal<HTMLDivElement>();

  return (
    <div ref={ref} className="relative z-10 text-foreground min-h-screen">
      {children}
    </div>
  );
}
