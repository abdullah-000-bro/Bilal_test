import Image from "next/image";

const TILES = [
  { src: "/assets/g1.jpg", span: "row-span-2", alt: "Editorial portrait in flowing black" },
  { src: "/assets/g2.jpg", span: "", alt: "Cuff detail of luxury black shirt" },
  { src: "/assets/g3.jpg", span: "", alt: "Model walking through smoke" },
  { src: "/assets/p3.jpg", span: "", alt: "Black bomber jacket" },
  { src: "/assets/g4.jpg", span: "row-span-2", alt: "Macro of gold and red embroidery" },
  { src: "/assets/p6.jpg", span: "", alt: "Cream sherwani detail" },
];

export function FashionGallery() {
  return (
    <section className="relative py-28 sm:py-36 px-5 sm:px-8">
      <div className="mx-auto max-w-7xl">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6 mb-14">
          <div>
            <div className="text-xs tracking-[0.3em] uppercase text-primary mb-4" data-reveal>
              · The Lookbook
            </div>
            <h2 className="font-display text-5xl sm:text-7xl leading-[0.95]" data-reveal>
              Worn by you.
            </h2>
          </div>
          <a
            href="#"
            className="text-sm text-foreground/70 hover:text-foreground underline underline-offset-8 decoration-primary"
            data-reveal
          >
            @bilalgarments on Instagram →
          </a>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 auto-rows-[180px] sm:auto-rows-[240px] gap-3 sm:gap-4">
          {TILES.map((tile, i) => (
            <div
              key={i}
              className={`group relative rounded-3xl overflow-hidden bg-card ${tile.span}`}
              data-reveal
            >
              <Image
                src={tile.src}
                alt={tile.alt}
                fill
                loading="lazy"
                className="object-cover transition-transform duration-[1200ms] ease-cinematic group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-background/0 group-hover:bg-background/20 transition-colors" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
