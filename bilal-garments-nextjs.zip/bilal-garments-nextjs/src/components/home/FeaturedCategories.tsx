import { ArrowUpRight } from "lucide-react";
import Image from "next/image";

const CATEGORIES = [
  { name: "Men", count: "84 pieces", img: "/assets/cat-men.jpg", accent: "From premium kurtas to tailored streetwear." },
  { name: "Boys", count: "42 pieces", img: "/assets/cat-boys.jpg", accent: "Modern fits engineered for the next generation." },
  { name: "Kids", count: "36 pieces", img: "/assets/cat-kids.jpg", accent: "Heirloom craftsmanship for the smallest icons." },
];

export function FeaturedCategories() {
  return (
    <section id="categories" className="relative py-28 sm:py-36 px-5 sm:px-8 scroll-mt-24">
      <div className="mx-auto max-w-7xl">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6 mb-14">
          <div>
            <div className="text-xs tracking-[0.3em] uppercase text-primary mb-4" data-reveal>
              · The Collections
            </div>
            <h2 className="font-display text-5xl sm:text-7xl leading-[0.95] max-w-2xl" data-reveal>
              Three worlds.<br />
              <span className="italic text-foreground/60">One signature.</span>
            </h2>
          </div>
          <p className="max-w-xs text-sm text-muted-foreground" data-reveal>
            Curated capsules for every chapter of life — built on the same obsession with detail.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 lg:gap-7">
          {CATEGORIES.map((cat) => (
            <a
              key={cat.name}
              href="#"
              className="group relative block rounded-3xl overflow-hidden bg-surface aspect-[3/4] shadow-luxury"
              data-reveal
            >
              <Image
                src={cat.img}
                alt={cat.name}
                fill
                loading="lazy"
                className="object-cover transition-transform duration-[1200ms] ease-cinematic group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background via-background/30 to-transparent" />

              <div className="absolute inset-x-0 bottom-0 p-7 sm:p-8 flex items-end justify-between gap-4">
                <div>
                  <div className="text-[10px] tracking-[0.3em] uppercase text-foreground/60 mb-2">
                    {cat.count}
                  </div>
                  <h3 className="font-display text-4xl sm:text-5xl leading-none">{cat.name}</h3>
                  <p className="mt-3 text-sm text-foreground/70 max-w-[14rem] hidden sm:block">
                    {cat.accent}
                  </p>
                </div>
                <div className="size-12 grid place-items-center rounded-full glass shrink-0 group-hover:bg-primary group-hover:border-primary transition-colors">
                  <ArrowUpRight className="size-5 transition-transform group-hover:rotate-45 ease-cinematic" />
                </div>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
