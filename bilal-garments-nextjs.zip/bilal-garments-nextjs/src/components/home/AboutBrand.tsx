import Image from "next/image";

export function AboutBrand() {
  return (
    <section id="about" className="relative py-28 sm:py-36 px-5 sm:px-8 overflow-hidden scroll-mt-24">
      <div className="mx-auto max-w-7xl grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16 items-center">
        <div className="lg:col-span-5 relative" data-reveal>
          <div className="relative aspect-[4/5] rounded-3xl overflow-hidden shadow-luxury">
            <Image
              src="/assets/brand.jpg"
              alt="A tailor crafting a luxury garment by lamplight"
              fill
              loading="lazy"
              className="object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-tr from-background/40 to-transparent" />
          </div>
          <div className="absolute -bottom-6 -right-2 sm:right-6 glass rounded-2xl p-5 shadow-luxury max-w-[14rem]">
            <div className="font-display text-3xl text-primary leading-none">07</div>
            <div className="mt-2 text-xs tracking-wide text-foreground/70">
              Years perfecting the cut. Every stitch, deliberate.
            </div>
          </div>
        </div>

        <div className="lg:col-span-7">
          <div className="text-xs tracking-[0.3em] uppercase text-primary mb-4" data-reveal>
            · The House of Bilal
          </div>
          <h2 className="font-display text-5xl sm:text-7xl leading-[0.95]" data-reveal>
            Heritage,<br />
            <span className="italic text-foreground/60">re-engineered.</span>
          </h2>
          <div className="mt-8 space-y-5 max-w-xl text-foreground/75 leading-relaxed">
            <p data-reveal>
              Born in Lahore, built for the world. We take centuries of
              Pakistani craftsmanship and translate it into silhouettes that
              feel as native to a Tokyo runway as they do to a Karachi rooftop.
            </p>
            <p data-reveal>
              Every piece is cut, sewn, and finished by hand in our atelier —
              limited runs, never reprinted. When it&apos;s gone, it&apos;s gone.
            </p>
          </div>
          <div className="mt-10 flex flex-wrap gap-x-10 gap-y-6" data-reveal>
            {[
              { k: "Hand-cut", v: "in-house atelier" },
              { k: "Limited", v: "no restocks" },
              { k: "Made in", v: "Lahore, PK" },
            ].map((item) => (
              <div key={item.k}>
                <div className="font-display text-xl">{item.k}</div>
                <div className="text-xs tracking-wider uppercase text-muted-foreground mt-1">
                  {item.v}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
