import { Sparkles, Truck, MapPin, ShieldCheck, Flame, Award } from "lucide-react";

const FEATURES = [
  { icon: Sparkles, title: "Premium Quality", body: "Hand-finished pieces, limited runs only." },
  { icon: Truck, title: "Fast Delivery", body: "48-hour shipping across major cities." },
  { icon: MapPin, title: "Nationwide Reach", body: "From Karachi to Skardu — we deliver." },
  { icon: ShieldCheck, title: "Secure Checkout", body: "JazzCash, EasyPaisa, COD, encrypted." },
  { icon: Flame, title: "Trend-First", body: "Drops engineered for the modern wardrobe." },
  { icon: Award, title: "Trusted Brand", body: "200,000+ customers and counting." },
];

export function WhyChooseUs() {
  return (
    <section className="relative py-28 sm:py-36 px-5 sm:px-8 bg-surface/40">
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-border to-transparent" />
      <div className="mx-auto max-w-7xl">
        <div className="text-center mb-16 sm:mb-20">
          <div className="text-xs tracking-[0.3em] uppercase text-primary mb-4" data-reveal>
            · Why BILAL
          </div>
          <h2 className="font-display text-5xl sm:text-7xl leading-[0.95] max-w-3xl mx-auto" data-reveal>
            Built for the<br />
            <span className="italic text-foreground/60">obsessed.</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 lg:gap-6">
          {FEATURES.map(({ icon: Icon, title, body }) => (
            <div
              key={title}
              className="group relative rounded-3xl glass p-7 sm:p-8 hover:bg-glass-border/20 transition-colors overflow-hidden"
              data-reveal
            >
              <div className="absolute -top-10 -right-10 size-40 bg-red-glow opacity-0 group-hover:opacity-100 blur-2xl transition-opacity duration-700" />
              <div className="relative">
                <div className="size-14 grid place-items-center rounded-2xl bg-surface-elevated border border-border mb-6 group-hover:border-primary transition-colors">
                  <Icon className="size-6 text-primary" strokeWidth={1.5} />
                </div>
                <h3 className="font-display text-2xl mb-2">{title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{body}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
