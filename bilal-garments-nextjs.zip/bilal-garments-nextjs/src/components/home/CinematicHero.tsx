"use client";

import { ArrowUpRight } from "lucide-react";
import Image from "next/image";

const scrollTo = (id: string) => {
  if (typeof document === "undefined") return;
  document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
};

export function CinematicHero() {
  return (
    <section className="relative min-h-[100svh] w-full overflow-hidden bg-noir">
      {/* Background portrait */}
      <div className="absolute inset-0">
        <Image
          src="/assets/hero.jpg"
          alt="Cinematic editorial portrait of a model wearing premium black streetwear"
          fill
          priority
          className="object-cover object-[60%_center] sm:object-[center_20%] opacity-90"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/70 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-background/40" />
        <div className="absolute -top-40 -right-40 size-[600px] bg-red-glow opacity-60 blur-3xl pointer-events-none animate-float-slow" />
      </div>

      {/* Content */}
      <div className="relative z-10 mx-auto max-w-7xl px-5 sm:px-8 pt-40 sm:pt-44 pb-20 min-h-[100svh] flex flex-col justify-center">
        <div className="max-w-3xl">
          <div
            className="inline-flex items-center gap-2 glass rounded-full px-4 py-1.5 mb-8 text-xs tracking-[0.25em] uppercase text-foreground/80"
            data-reveal
          >
            <span className="size-1.5 rounded-full bg-primary animate-pulse" />
            New Drop · Winter &apos;26
          </div>

          <h1
            className="font-display text-[clamp(3rem,11vw,9rem)] leading-[0.9] tracking-tight"
            data-reveal
          >
            Wear the
            <br />
            <span className="italic text-primary">Cinematic.</span>
          </h1>

          <p
            className="mt-8 max-w-md text-base sm:text-lg text-foreground/70 leading-relaxed"
            data-reveal
          >
            A new era of Pakistani luxury. Hand-tailored silhouettes engineered
            for the bold, the modern, the unforgettable.
          </p>

          <div className="mt-10 flex flex-wrap items-center gap-3" data-reveal>
            <button
              onClick={() => scrollTo("collection")}
              className="group inline-flex items-center gap-2 rounded-full bg-primary px-7 py-4 text-sm font-medium text-primary-foreground shadow-[0_10px_40px_-10px_var(--primary)] hover:scale-[1.02] transition-transform ease-luxury"
            >
              Shop Collection
              <ArrowUpRight className="size-4 group-hover:rotate-45 transition-transform ease-luxury" />
            </button>
            <button
              onClick={() => scrollTo("about")}
              className="inline-flex items-center gap-2 rounded-full glass px-7 py-4 text-sm font-medium hover:bg-glass-border/30 transition-colors"
            >
              Explore the Story
            </button>
          </div>

          <div className="mt-16 grid grid-cols-3 gap-6 max-w-md" data-reveal>
            {[
              { k: "1.2M+", v: "Garments shipped" },
              { k: "4.9★", v: "Customer rating" },
              { k: "48h", v: "Nationwide delivery" },
            ].map((s) => (
              <div key={s.v}>
                <div className="font-display text-2xl sm:text-3xl">{s.k}</div>
                <div className="text-[11px] sm:text-xs uppercase tracking-wider text-muted-foreground mt-1">
                  {s.v}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Scroll cue */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-2 text-[10px] tracking-[0.3em] uppercase text-foreground/50">
        Scroll
        <div className="h-10 w-px bg-gradient-to-b from-foreground/60 to-transparent" />
      </div>
    </section>
  );
}
