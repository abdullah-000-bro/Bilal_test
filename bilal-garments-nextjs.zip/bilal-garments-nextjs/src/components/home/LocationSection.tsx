"use client";

import { MapPin, Phone, Mail, Clock } from "lucide-react";
import { toast } from "sonner";

export function LocationSection() {
  return (
    <section id="location" className="relative py-28 sm:py-36 px-5 sm:px-8 bg-surface/40 scroll-mt-24">
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-border to-transparent" />
      <div className="mx-auto max-w-7xl grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
        <div>
          <div className="text-xs tracking-[0.3em] uppercase text-primary mb-4" data-reveal>
            · Visit the Atelier
          </div>
          <h2 className="font-display text-5xl sm:text-7xl leading-[0.95]" data-reveal>
            Lahore.<br />
            <span className="italic text-foreground/60">By appointment.</span>
          </h2>
          <p className="mt-8 max-w-md text-foreground/75 leading-relaxed" data-reveal>
            Step inside the studio for private fittings, custom commissions,
            and first looks at unreleased capsules.
          </p>

          <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-xl">
            {[
              { icon: MapPin, label: "Studio", value: "MM Alam Road, Gulberg III, Lahore" },
              { icon: Phone, label: "Phone", value: "+92 300 0000000" },
              { icon: Mail, label: "Email", value: "studio@bilalgarments.pk" },
              { icon: Clock, label: "Hours", value: "Mon – Sat · 12pm – 9pm" },
            ].map(({ icon: Icon, label, value }) => (
              <div key={label} className="glass rounded-2xl p-5 flex gap-4 items-start" data-reveal>
                <div className="size-10 grid place-items-center rounded-xl bg-surface-elevated border border-border shrink-0">
                  <Icon className="size-4 text-primary" strokeWidth={1.5} />
                </div>
                <div className="min-w-0">
                  <div className="text-[10px] tracking-[0.25em] uppercase text-muted-foreground mb-1">
                    {label}
                  </div>
                  <div className="text-sm leading-snug truncate">{value}</div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-8 flex flex-wrap gap-3" data-reveal>
            <button
              onClick={() =>
                toast.success("Appointment request sent", {
                  description: "We'll confirm via WhatsApp shortly.",
                })
              }
              className="px-6 py-3.5 rounded-full bg-primary text-primary-foreground text-sm font-medium hover:opacity-90"
            >
              Book Appointment
            </button>
            <a
              href="https://www.openstreetmap.org/?mlat=31.5204&mlon=74.3587#map=17/31.5204/74.3587"
              target="_blank"
              rel="noreferrer"
              className="px-6 py-3.5 rounded-full glass text-sm font-medium hover:bg-glass-border/30 transition-colors"
            >
              Get Directions
            </a>
          </div>
        </div>

        <div
          className="relative rounded-3xl overflow-hidden shadow-luxury aspect-[5/6] lg:aspect-square glass"
          data-reveal
        >
          <iframe
            title="BILAL GARMENTS Atelier — Lahore"
            src="https://www.openstreetmap.org/export/embed.html?bbox=74.34%2C31.51%2C74.36%2C31.53&layer=mapnik&marker=31.5204%2C74.3587"
            className="absolute inset-0 h-full w-full grayscale contrast-125 invert hue-rotate-180 opacity-90"
            loading="lazy"
          />
          <div className="absolute inset-0 pointer-events-none bg-gradient-to-t from-background/60 via-transparent to-background/30" />
          <div className="absolute bottom-5 left-5 right-5 glass rounded-2xl p-4 flex items-center gap-3">
            <div className="size-2 rounded-full bg-primary animate-pulse" />
            <div className="text-xs tracking-wide">31.5204° N, 74.3587° E · Lahore, Pakistan</div>
          </div>
        </div>
      </div>
    </section>
  );
}
