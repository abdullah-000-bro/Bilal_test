"use client";

import { Heart } from "lucide-react";
import Link from "next/link";
import Image from "next/image";
import { PRODUCTS as ALL, fmtPKR as fmt } from "@/lib/products";
import { useStore } from "@/lib/store";

const PRODUCTS = ALL.slice(0, 6);

export function TrendingCollection() {
  const { addToCart, toggleWishlist, isWished } = useStore();
  return (
    <section id="collection" className="relative py-28 sm:py-36 px-5 sm:px-8 bg-surface/40 scroll-mt-24">
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-border to-transparent" />
      <div className="mx-auto max-w-7xl">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6 mb-14">
          <div>
            <div className="text-xs tracking-[0.3em] uppercase text-primary mb-4" data-reveal>
              · Trending Now
            </div>
            <h2 className="font-display text-5xl sm:text-7xl leading-[0.95]" data-reveal>
              The Edit.
            </h2>
          </div>
          <Link
            href="/shop"
            className="text-sm text-foreground/70 hover:text-foreground underline underline-offset-8 decoration-primary"
            data-reveal
          >
            View full collection →
          </Link>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 lg:gap-8">
          {PRODUCTS.map((p) => (
            <article key={p.name} className="group relative" data-reveal>
              <div className="relative aspect-[3/4] rounded-3xl overflow-hidden bg-card shadow-float">
                <Link href={`/product/${p.id}`} aria-label={p.name} className="absolute inset-0 z-10">
                  <Image
                    src={p.img}
                    alt={p.name}
                    fill
                    loading="lazy"
                    className="object-cover transition-transform duration-[1200ms] ease-cinematic group-hover:scale-105"
                  />
                </Link>
                {p.tag && (
                  <span className="absolute top-4 left-4 z-20 px-3 py-1 rounded-full text-[10px] tracking-[0.2em] uppercase glass">
                    <span className={p.tag === "New" || p.tag === "Limited" ? "text-primary" : ""}>
                      {p.tag}
                    </span>
                  </span>
                )}
                <button
                  aria-label={isWished(p.id) ? "Remove from wishlist" : "Add to wishlist"}
                  onClick={() => toggleWishlist(p.id, p.name)}
                  className="absolute top-4 right-4 z-20 size-10 grid place-items-center rounded-full glass opacity-100 sm:opacity-0 sm:group-hover:opacity-100 transition-all hover:scale-110"
                >
                  <Heart
                    className={`size-4 transition-colors ${isWished(p.id) ? "fill-primary text-primary" : ""}`}
                  />
                </button>
                <div className="absolute inset-x-3 bottom-3 z-20 translate-y-2 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-500 ease-cinematic">
                  <button
                    onClick={() => addToCart({ id: p.id, name: p.name, price: p.price, img: p.img })}
                    className="w-full py-3 rounded-full bg-foreground text-background text-xs font-semibold tracking-wider uppercase hover:bg-primary hover:text-primary-foreground transition-colors"
                  >
                    Add to Bag
                  </button>
                </div>
              </div>
              <div className="mt-4 flex items-start justify-between gap-3 px-1">
                <Link
                  href={`/product/${p.id}`}
                  className="text-sm sm:text-base font-medium leading-snug hover:text-primary transition-colors"
                >
                  {p.name}
                </Link>
                <span className="text-sm sm:text-base whitespace-nowrap text-foreground/80">
                  {fmt(p.price)}
                </span>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
