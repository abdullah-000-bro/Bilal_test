import { Star } from "lucide-react";

const REVIEWS = [
  {
    name: "Hamza Ali", city: "Karachi", rating: 5,
    text: "The cut, the fabric, the finish — every detail feels considered. I've never owned a kurta this sharp.",
    initials: "HA",
  },
  {
    name: "Ayesha Khan", city: "Lahore", rating: 5,
    text: "Ordered for my brother's mehendi. The piece arrived in a wax-sealed box. He hasn't stopped talking about it.",
    initials: "AK",
  },
  {
    name: "Bilal Sheikh", city: "Islamabad", rating: 5,
    text: "Bilal Garments ne meri shaadi ke outfit ko legendary bana diya. Tailoring world-class hai.",
    initials: "BS",
  },
];

export function Reviews() {
  return (
    <section id="reviews" className="relative py-24 sm:py-32 px-5 sm:px-8 overflow-hidden scroll-mt-24">
      <div aria-hidden className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute left-1/2 top-1/3 -translate-x-1/2 size-[50vmax] rounded-full bg-red-glow opacity-20 blur-3xl" />
      </div>

      <div className="mx-auto max-w-6xl">
        <div className="flex flex-col items-center text-center mb-14 sm:mb-20">
          <div className="text-xs tracking-[0.3em] uppercase text-primary mb-4" data-reveal>
            · Words from the House
          </div>
          <h2 className="font-display text-5xl sm:text-7xl leading-[0.95] max-w-3xl" data-reveal>
            Worn by the bold.<br />
            <span className="italic text-foreground/50">Reviewed by the rest.</span>
          </h2>
          <div className="mt-8 flex items-center gap-3 text-sm text-foreground/60" data-reveal>
            <div className="flex gap-1">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} className="size-4 fill-primary text-primary" strokeWidth={1.2} />
              ))}
            </div>
            <span className="tracking-wide">4.9 / 5 · over 1,200 verified clients</span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 sm:gap-6 items-start">
          {/* Card 1 — large */}
          <article
            data-reveal
            className="lg:col-span-7 group relative glass rounded-[2rem] p-7 sm:p-9 transition-all duration-700 ease-luxury hover:-translate-y-2 hover:shadow-luxury overflow-hidden"
          >
            <span className="absolute -top-6 -left-3 font-display text-[10rem] leading-none text-primary/6 select-none pointer-events-none">
              &ldquo;
            </span>
            <div className="relative z-10">
              <div className="flex gap-0.5 mb-6">
                {Array.from({ length: REVIEWS[0].rating }).map((_, i) => (
                  <Star key={i} className="size-4 fill-primary text-primary" strokeWidth={1.2} />
                ))}
              </div>
              <p className="text-lg sm:text-xl leading-relaxed text-foreground/90 mb-10 max-w-xl">
                &ldquo;{REVIEWS[0].text}&rdquo;
              </p>
              <div className="flex items-center gap-4 pt-6 border-t border-border/50">
                <div className="size-12 rounded-full bg-gradient-to-br from-primary/90 to-primary/40 grid place-items-center font-display text-base tracking-wider text-primary-foreground shadow-glow">
                  {REVIEWS[0].initials}
                </div>
                <div>
                  <div className="text-base font-medium">{REVIEWS[0].name}</div>
                  <div className="text-xs tracking-[0.2em] uppercase text-muted-foreground mt-0.5">
                    {REVIEWS[0].city} · Verified Purchase
                  </div>
                </div>
              </div>
            </div>
          </article>

          {/* Right column */}
          <div className="lg:col-span-5 flex flex-col gap-5 sm:gap-6">
            {REVIEWS.slice(1).map((review) => (
              <article
                key={review.name}
                data-reveal
                className="group relative glass rounded-3xl p-6 sm:p-7 transition-all duration-700 ease-luxury hover:-translate-y-2 hover:shadow-luxury overflow-hidden"
              >
                <span className="absolute top-2 right-4 font-display text-6xl leading-none text-primary/8 select-none pointer-events-none">
                  &rdquo;
                </span>
                <div className="relative z-10">
                  <div className="flex gap-0.5 mb-4">
                    {Array.from({ length: review.rating }).map((_, i) => (
                      <Star key={i} className="size-3.5 fill-primary text-primary" strokeWidth={1.2} />
                    ))}
                  </div>
                  <p className="text-[15px] leading-relaxed text-foreground/85 mb-6">
                    &ldquo;{review.text}&rdquo;
                  </p>
                  <div className="flex items-center gap-3 pt-4 border-t border-border/50">
                    <div className="size-10 rounded-full bg-gradient-to-br from-primary/80 to-primary/30 grid place-items-center font-display text-sm tracking-wider text-primary-foreground shadow-glow">
                      {review.initials}
                    </div>
                    <div>
                      <div className="text-sm font-medium">{review.name}</div>
                      <div className="text-[11px] tracking-[0.2em] uppercase text-muted-foreground mt-0.5">
                        {review.city} · Verified
                      </div>
                    </div>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
