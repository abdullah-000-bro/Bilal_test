"use client";

import Link from "next/link";
import { useRouter, usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { Search, ShoppingBag, Menu, X } from "lucide-react";
import { useStore } from "@/lib/store";
import { SearchOverlay } from "./SearchOverlay";

const NAV: Array<{ label: string; href?: string; to?: string }> = [
  { label: "Shop", to: "/shop" },
  { label: "Men", href: "#categories" },
  { label: "Boys", href: "#categories" },
  { label: "Kids", href: "#categories" },
  { label: "About", href: "#about" },
  { label: "Contact", href: "#location" },
];

export function LuxuryHeader() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const { cartCount } = useStore();
  const router = useRouter();
  const pathname = usePathname();

  const go = (item: { href?: string; to?: string }) => {
    setOpen(false);
    if (item.to) {
      router.push(item.to);
      return;
    }
    if (!item.href) return;
    const id = item.href.replace("#", "");
    if (typeof window !== "undefined" && pathname !== "/") {
      router.push(`/#${id}`);
      return;
    }
    const el = typeof document !== "undefined" ? document.getElementById(id) : null;
    el?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <>
      <header
        className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ease-cinematic ${
          scrolled ? "px-3 py-2 sm:px-6 sm:py-4" : "px-3 py-3 sm:px-8 sm:py-6"
        }`}
      >
        <div
          className={`mx-auto flex items-center justify-between transition-all duration-500 ease-cinematic glass rounded-full ${
            scrolled
              ? "max-w-5xl px-4 py-2 shadow-luxury sm:px-6 sm:py-3"
              : "max-w-6xl px-5 py-3 sm:px-8 sm:py-4"
          }`}
        >
          <Link href="/" className="flex items-center gap-2 shrink-0">
            <span className="font-display text-xl sm:text-2xl tracking-[0.2em]">
              BILAL<span className="text-primary">.</span>
            </span>
          </Link>

          <nav className="hidden lg:flex items-center gap-1">
            {NAV.map((item) => (
              <button
                key={item.label}
                onClick={() => go(item)}
                className="px-4 py-2 text-sm tracking-wide text-foreground/80 hover:text-foreground transition-colors rounded-full hover:bg-glass"
              >
                {item.label}
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-1 sm:gap-2">
            <button
              aria-label="Search"
              onClick={() => setSearchOpen(true)}
              className="p-2 sm:p-2.5 rounded-full hover:bg-glass transition-colors"
            >
              <Search className="size-4 sm:size-[18px]" />
            </button>
            <Link
              href="/cart"
              aria-label={`Cart, ${cartCount} items`}
              className="relative p-2 sm:p-2.5 rounded-full hover:bg-glass transition-colors"
            >
              <ShoppingBag className="size-4 sm:size-[18px]" />
              {cartCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 size-4 grid place-items-center rounded-full bg-primary text-[10px] font-semibold text-primary-foreground">
                  {cartCount}
                </span>
              )}
            </Link>
            <button
              aria-label="Menu"
              onClick={() => setOpen(true)}
              className="lg:hidden p-2 rounded-full hover:bg-glass transition-colors"
            >
              <Menu className="size-4 sm:size-[18px]" />
            </button>
            <Link
              href="/shop"
              className="hidden lg:inline-flex ml-1 px-5 py-2.5 rounded-full bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition-opacity"
            >
              Shop Now
            </Link>
          </div>
        </div>
      </header>

      {/* Mobile menu */}
      <div
        className={`fixed inset-0 z-[60] lg:hidden transition-all duration-500 ease-cinematic ${
          open ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
        }`}
      >
        <div
          className="absolute inset-0 bg-background/90 backdrop-blur-xl"
          onClick={() => setOpen(false)}
        />
        <div
          className={`absolute right-3 top-3 bottom-3 w-[88vw] max-w-sm rounded-3xl glass shadow-luxury p-6 flex flex-col transition-transform duration-500 ease-cinematic ${
            open ? "translate-x-0" : "translate-x-[110%]"
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="font-display text-xl tracking-[0.2em]">
              BILAL<span className="text-primary">.</span>
            </span>
            <button
              aria-label="Close"
              onClick={() => setOpen(false)}
              className="p-2 rounded-full hover:bg-glass"
            >
              <X className="size-5" />
            </button>
          </div>
          <nav className="mt-8 flex flex-col gap-1">
            {NAV.map((item) => (
              <button
                key={item.label}
                onClick={() => go(item)}
                className="text-left px-4 py-3 text-lg font-display tracking-wide rounded-2xl hover:bg-glass"
              >
                {item.label}
              </button>
            ))}
          </nav>
          <Link
            href="/shop"
            onClick={() => setOpen(false)}
            className="mt-auto px-5 py-3.5 rounded-full bg-primary text-primary-foreground font-medium text-center"
          >
            Shop the Collection
          </Link>
        </div>
      </div>

      <SearchOverlay open={searchOpen} onClose={() => setSearchOpen(false)} />
    </>
  );
}
