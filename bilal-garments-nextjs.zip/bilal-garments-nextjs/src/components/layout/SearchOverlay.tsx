"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { Search, X, ArrowRight } from "lucide-react";
import { PRODUCTS, fmtPKR } from "@/lib/products";
import Image from "next/image";

type Props = { open: boolean; onClose: () => void };

const TRENDING = ["Sherwani", "Kurta", "Bomber", "Hoodie", "Waistcoat"];

export function SearchOverlay({ open, onClose }: Props) {
  const [q, setQ] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!open) return;
    const t = setTimeout(() => inputRef.current?.focus(), 80);
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      clearTimeout(t);
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);

  useEffect(() => {
    if (!open) setQ("");
  }, [open]);

  const results = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return [];
    return PRODUCTS.filter(
      (p) =>
        p.name.toLowerCase().includes(s) ||
        p.category.toLowerCase().includes(s) ||
        p.description.toLowerCase().includes(s),
    ).slice(0, 6);
  }, [q]);

  return (
    <div
      className={`fixed inset-0 z-[70] transition-all duration-500 ease-cinematic ${
        open ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
      }`}
      aria-hidden={!open}
    >
      <div
        className="absolute inset-0 bg-background/85 backdrop-blur-2xl"
        onClick={onClose}
      />
      <div
        className={`relative mx-auto mt-16 sm:mt-24 w-[94vw] max-w-2xl rounded-3xl glass shadow-luxury p-3 sm:p-5 transition-all duration-500 ease-cinematic ${
          open ? "translate-y-0 opacity-100" : "-translate-y-4 opacity-0"
        }`}
      >
        <div className="flex items-center gap-2 px-3 py-2 rounded-2xl bg-glass">
          <Search className="size-4 sm:size-5 text-foreground/60 shrink-0" />
          <input
            ref={inputRef}
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search kurtas, sherwanis, jackets…"
            className="flex-1 bg-transparent outline-none text-sm sm:text-base placeholder:text-foreground/40 py-2"
          />
          <button
            aria-label="Close search"
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-glass"
          >
            <X className="size-4" />
          </button>
        </div>

        {!q && (
          <div className="px-3 sm:px-4 mt-5">
            <p className="text-[10px] sm:text-xs uppercase tracking-[0.25em] text-foreground/50 mb-3">
              Trending
            </p>
            <div className="flex flex-wrap gap-2">
              {TRENDING.map((t) => (
                <button
                  key={t}
                  onClick={() => setQ(t)}
                  className="px-3 py-1.5 rounded-full text-xs sm:text-sm bg-glass hover:bg-foreground hover:text-background transition-colors"
                >
                  {t}
                </button>
              ))}
            </div>
          </div>
        )}

        {q && (
          <div className="mt-3 max-h-[60vh] overflow-y-auto no-scrollbar">
            {results.length === 0 ? (
              <div className="px-4 py-10 text-center text-sm text-foreground/60">
                No matches for &ldquo;{q}&rdquo;.
              </div>
            ) : (
              <ul className="flex flex-col">
                {results.map((p) => (
                  <li key={p.id}>
                    <Link
                      href={`/product/${p.id}`}
                      onClick={onClose}
                      className="group flex items-center gap-3 p-2 sm:p-3 rounded-2xl hover:bg-glass transition-colors"
                    >
                      <div className="size-14 sm:size-16 rounded-xl overflow-hidden bg-card shrink-0 relative">
                        <Image
                          src={p.img}
                          alt={p.name}
                          fill
                          className="object-cover transition-transform duration-700 group-hover:scale-110"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm sm:text-base font-medium truncate">{p.name}</p>
                        <p className="text-[11px] sm:text-xs text-foreground/50 uppercase tracking-wider">
                          {p.category} · {fmtPKR(p.price)}
                        </p>
                      </div>
                      <ArrowRight className="size-4 text-foreground/40 group-hover:text-primary transition-colors" />
                    </Link>
                  </li>
                ))}
              </ul>
            )}
            <div className="mt-2 px-3 py-2 border-t border-border/40">
              <Link
                href="/shop"
                onClick={onClose}
                className="text-xs sm:text-sm text-primary hover:underline"
              >
                Browse the full collection →
              </Link>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
