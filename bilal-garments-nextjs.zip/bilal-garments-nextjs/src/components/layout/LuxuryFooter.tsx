"use client";

import Link from "next/link";
import { Instagram, Facebook, Youtube } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const COLS = [
  { title: "Shop", links: ["Men", "Boys", "Kids", "New Arrivals", "Sale"] },
  { title: "House", links: ["About", "Atelier", "Press", "Sustainability", "Careers"] },
  { title: "Help", links: ["Shipping", "Returns", "Size Guide", "Contact", "FAQs"] },
];

export function LuxuryFooter() {
  const [email, setEmail] = useState("");
  return (
    <footer className="relative pt-24 pb-10 px-5 sm:px-8 overflow-hidden">
      {/* Massive wordmark */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 -bottom-6 sm:-bottom-12 text-center font-display tracking-[-0.02em] leading-none select-none"
        style={{
          fontSize: "clamp(6rem, 22vw, 22rem)",
          background: "linear-gradient(to bottom, oklch(1 0 0 / 0.10), transparent 80%)",
          WebkitBackgroundClip: "text",
          backgroundClip: "text",
          color: "transparent",
        }}
      >
        BILAL.
      </div>

      <div className="relative mx-auto max-w-7xl">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 pb-16 border-b border-border">
          <div className="lg:col-span-5">
            <Link href="/" className="font-display text-3xl tracking-[0.2em]">
              BILAL<span className="text-primary">.</span>
            </Link>
            <p className="mt-6 max-w-sm text-sm text-muted-foreground leading-relaxed">
              Hand-tailored luxury, engineered in Lahore. Sign up to get first
              access to drops before they&apos;re gone.
            </p>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!email) return;
                toast.success("You're on the list", {
                  description: `We'll email ${email} when the next drop lands.`,
                });
                setEmail("");
              }}
              className="mt-6 flex max-w-md glass rounded-full p-1.5"
            >
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="your@email.com"
                aria-label="Email"
                className="flex-1 bg-transparent px-4 py-2 text-sm placeholder:text-muted-foreground focus:outline-none"
              />
              <button
                type="submit"
                className="rounded-full bg-primary text-primary-foreground px-5 py-2 text-sm font-medium hover:opacity-90 transition-opacity"
              >
                Join
              </button>
            </form>
            <div className="mt-8 flex gap-3">
              {[Instagram, Facebook, Youtube].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  aria-label="Social link"
                  className="size-11 grid place-items-center rounded-full glass hover:bg-primary hover:border-primary transition-colors"
                >
                  <Icon className="size-4" strokeWidth={1.5} />
                </a>
              ))}
            </div>
          </div>

          {COLS.map((col) => (
            <div key={col.title} className="lg:col-span-2">
              <div className="text-[10px] tracking-[0.3em] uppercase text-primary mb-5">
                {col.title}
              </div>
              <ul className="space-y-3">
                {col.links.map((l) => (
                  <li key={l}>
                    <a
                      href="#"
                      className="text-sm text-foreground/75 hover:text-foreground transition-colors"
                    >
                      {l}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          <div className="lg:col-span-1 flex lg:justify-end">
            <div className="flex flex-wrap gap-2">
              {["VISA", "MC", "JC", "EP", "COD"].map((p) => (
                <span key={p} className="px-2.5 py-1.5 rounded-md glass text-[10px] tracking-wider">
                  {p}
                </span>
              ))}
            </div>
          </div>
        </div>

        <div className="pt-8 flex flex-col sm:flex-row gap-4 justify-between text-xs text-muted-foreground">
          <div>© {new Date().getFullYear()} BILAL GARMENTS. All rights reserved.</div>
          <div className="flex gap-6">
            <a href="#" className="hover:text-foreground">Privacy</a>
            <a href="#" className="hover:text-foreground">Terms</a>
            <a href="#" className="hover:text-foreground">Cookies</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
