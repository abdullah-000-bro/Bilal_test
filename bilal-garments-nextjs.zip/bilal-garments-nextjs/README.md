# BILAL GARMENTS — Next.js

Yeh project **TanStack Start (Vite)** se **Next.js 15 (App Router)** me convert kiya gaya hai.

## Project Structure

```
src/
├── app/
│   ├── layout.tsx          # Root layout (fonts, providers, toaster)
│   ├── page.tsx            # Home page
│   ├── not-found.tsx       # 404 page
│   ├── globals.css         # All design tokens + animations
│   ├── shop/               # Shop page
│   ├── cart/               # Cart + checkout
│   ├── product/[id]/       # Dynamic product page
│   └── admin/              # Admin panel
│       ├── layout.tsx
│       ├── page.tsx         # Dashboard
│       ├── login/
│       ├── products/
│       ├── orders/
│       ├── analytics/
│       ├── customers/
│       └── settings/
├── components/
│   ├── home/               # All home section components
│   └── layout/             # Header, Footer, AmbientBackground, SearchOverlay
├── hooks/
│   ├── useLenis.ts         # Smooth scroll
│   └── useGsapReveal.ts    # GSAP scroll animations
└── lib/
    ├── products.ts          # Product data
    ├── store.tsx            # Cart + wishlist context
    └── admin-store.tsx      # Admin context (orders, customers, products, settings)
```

## Setup & Run

```bash
npm install
npm run dev
```

Phir open karo: http://localhost:3000

## Admin Panel

- URL: http://localhost:3000/admin
- Username: `admin`
- Password: `admin123`

## Key Conversions (TanStack → Next.js)

| TanStack Start | Next.js Equivalent |
|---|---|
| `createFileRoute("/")` | `export default function Page()` |
| `Link to="/shop"` | `Link href="/shop"` |
| `useNavigate()` | `useRouter()` from `next/navigation` |
| `useLocation()` | `usePathname()` |
| `<img src={...}>` | `<Image src={...} fill>` |
| `Outlet` | `{children}` in layout |
| `createRootRoute` | `app/layout.tsx` |
| `head()` meta | `export const metadata` |
| Route loaders | `generateMetadata` + server components |

## Assets

Saari images `/public/assets/` me hain aur `/assets/filename.jpg` se accessible hain.

## Dependencies

Same dependencies rakhi hain — GSAP, Lenis, Recharts, Lucide, Tailwind, Sonner, Radix UI. Sirf TanStack Router/Start packages remove ki gai hain.
