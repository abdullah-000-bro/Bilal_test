/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        display: ["Italiana", "Cormorant Garamond", "serif"],
        sans: ["Inter Tight", "Inter", "system-ui", "sans-serif"],
      },
      colors: {
        background: "oklch(0.06 0 0)",
        foreground: "oklch(0.97 0 0)",
        primary: {
          DEFAULT: "oklch(0.62 0.24 25)",
          foreground: "oklch(0.98 0 0)",
        },
        secondary: {
          DEFAULT: "oklch(0.15 0 0)",
          foreground: "oklch(0.97 0 0)",
        },
        muted: {
          DEFAULT: "oklch(0.15 0 0)",
          foreground: "oklch(0.62 0 0)",
        },
        card: {
          DEFAULT: "oklch(0.10 0 0)",
          foreground: "oklch(0.97 0 0)",
        },
        border: "oklch(1 0 0 / 0.08)",
        surface: "oklch(0.09 0 0)",
      },
      animation: {
        marquee: "marquee 80s linear infinite",
        "marquee-reverse": "marquee 100s linear infinite reverse",
        "float-slow": "float-slow 9s ease-in-out infinite",
        "drift-a": "drift-a 28s ease-in-out infinite alternate",
        "drift-b": "drift-b 34s ease-in-out infinite alternate",
        "drift-c": "drift-c 40s ease-in-out infinite alternate",
      },
      keyframes: {
        marquee: {
          "0%": { transform: "translateX(0)" },
          "100%": { transform: "translateX(-50%)" },
        },
        "float-slow": {
          "0%, 100%": { transform: "translateY(0)" },
          "50%": { transform: "translateY(-10px)" },
        },
        "drift-a": {
          "0%": { transform: "translate3d(0, 0, 0) scale(1)", opacity: "0.55" },
          "50%": { transform: "translate3d(6vw, 4vh, 0) scale(1.08)", opacity: "0.65" },
          "100%": { transform: "translate3d(-4vw, 8vh, 0) scale(0.95)", opacity: "0.5" },
        },
        "drift-b": {
          "0%": { transform: "translate3d(0, 0, 0) scale(1)", opacity: "0.45" },
          "50%": { transform: "translate3d(-8vw, -6vh, 0) scale(1.1)", opacity: "0.6" },
          "100%": { transform: "translate3d(4vw, 6vh, 0) scale(0.92)", opacity: "0.4" },
        },
        "drift-c": {
          "0%": { transform: "translate3d(0, 0, 0) scale(1)", opacity: "0.4" },
          "50%": { transform: "translate3d(5vw, -8vh, 0) scale(1.05)", opacity: "0.55" },
          "100%": { transform: "translate3d(-6vw, -2vh, 0) scale(0.98)", opacity: "0.35" },
        },
      },
      boxShadow: {
        luxury: "0 30px 80px -30px oklch(0 0 0 / 0.7), 0 8px 30px -10px oklch(0 0 0 / 0.4)",
        float: "0 20px 50px -20px oklch(0 0 0 / 0.6)",
        glow: "0 0 60px -10px oklch(0.62 0.24 25)",
      },
      transitionTimingFunction: {
        luxury: "cubic-bezier(0.65, 0, 0.35, 1)",
        cinematic: "cubic-bezier(0.22, 1, 0.36, 1)",
      },
    },
  },
  plugins: [],
};
